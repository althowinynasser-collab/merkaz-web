# ربط playmerkaz.com بمركاز

تم تجهيز النسخة للعمل على:
- https://playmerkaz.com
- https://www.playmerkaz.com

## الخطوات
1. انشر المشروع على Render.
2. بعد نجاح النشر أضف في Render > Settings > Custom Domains:
   - playmerkaz.com
   - www.playmerkaz.com
3. انسخ سجلات DNS التي يعطيك إياها Render.
4. في Namecheap: Domain List > playmerkaz.com > Manage > Advanced DNS.
5. أضف السجلات التي يعرضها Render بالضبط.
6. انتظر حتى تصبح حالة الدومين Verified ويصدر SSL.
7. افتح https://playmerkaz.com

مهم: لا نضع قيم DNS افتراضية قبل ظهورها من Render لأن القيم قد تختلف بحسب الخدمة.

## متغيرات الإنتاج
```env
NODE_ENV=production
TRUST_PROXY=1
APP_ORIGIN=https://playmerkaz.com,https://www.playmerkaz.com
CANONICAL_HOST=playmerkaz.com
FORCE_HTTPS=1
MERKAZ_DB=/var/data/merkaz.sqlite
JWT_SECRET=<سر طويل وعشوائي>
```

## اختبار 4 جوالات
- افتح الدومين من 4 جوالات.
- أنشئ 4 حسابات.
- أنشئ مجلسًا من الجوال الأول.
- ادخل بالرمز من الثلاثة الآخرين.
- أكمل مباراة كاملة.
- اختبر انقطاع أحد الجوالات وعودته.
- اختبر الدردشة والفلترة والبلاغات.
