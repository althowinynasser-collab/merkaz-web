import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { db, createUser, userByUsername, userById, now, touchUser } from "./db.js";

const JWT_SECRET=process.env.JWT_SECRET || "CHANGE_ME_MERKAZ_DEV_SECRET";
if(process.env.NODE_ENV==="production" && JWT_SECRET==="CHANGE_ME_MERKAZ_DEV_SECRET"){
  throw new Error("JWT_SECRET must be set in production");
}
const TOKEN_TTL_SECONDS=60*60*24*30;

export function validateUsername(v=""){
  return /^[A-Za-z0-9_]{3,20}$/.test(v);
}

export async function registerAccount({username,password,displayName}){
  username=String(username||"").trim();
  displayName=String(displayName||"").trim();
  if(!validateUsername(username)) throw new Error("اسم المستخدم يجب أن يكون 3-20 حرفًا إنجليزيًا/رقمًا أو _");
  if(String(password||"").length<8) throw new Error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
  if(displayName.length<2 || displayName.length>24) throw new Error("الاسم الظاهر غير صالح");
  if(userByUsername(username)) throw new Error("اسم المستخدم مستخدم");
  const passwordHash=await bcrypt.hash(password,12);
  return createUser({username,passwordHash,displayName});
}

export async function loginAccount({username,password}){
  const row=userByUsername(String(username||"").trim());
  if(!row) throw new Error("بيانات الدخول غير صحيحة");
  const ok=await bcrypt.compare(String(password||""),row.password_hash);
  if(!ok) throw new Error("بيانات الدخول غير صحيحة");
  touchUser(row.id);
  return userById(row.id);
}

export function issueToken(user){
  const sid=crypto.randomUUID();
  const expiresAt=now()+TOKEN_TTL_SECONDS*1000;
  db.prepare(`INSERT INTO sessions(id,user_id,created_at,expires_at) VALUES(?,?,?,?)`)
    .run(sid,user.id,now(),expiresAt);
  return jwt.sign({sub:String(user.id),sid},JWT_SECRET,{expiresIn:TOKEN_TTL_SECONDS});
}

export function verifyToken(token){
  try{
    const p=jwt.verify(token,JWT_SECRET);
    const session=db.prepare(`SELECT * FROM sessions WHERE id=? AND revoked_at IS NULL AND expires_at>?`).get(p.sid,now());
    if(!session)return null;
    const user=userById(Number(p.sub));
    if(!user)return null;
    return {user,session};
  }catch{return null;}
}

export function authMiddleware(req,res,next){
  const h=req.headers.authorization||"";
  const token=h.startsWith("Bearer ")?h.slice(7):null;
  const a=token?verifyToken(token):null;
  if(!a)return res.status(401).json({ok:false,error:"unauthorized"});
  req.auth=a;next();
}
