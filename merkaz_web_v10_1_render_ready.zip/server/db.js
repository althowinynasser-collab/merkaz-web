import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const dbPath=process.env.MERKAZ_DB || path.join(__dirname,"merkaz.sqlite");
export const db=new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  rank_name TEXT NOT NULL DEFAULT 'ضيف',
  level INTEGER NOT NULL DEFAULT 1,
  xp INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions(
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  revoked_at INTEGER,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS matches(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_code TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  ended_at INTEGER NOT NULL,
  team_us_score INTEGER NOT NULL,
  team_them_score INTEGER NOT NULL,
  winner_team TEXT NOT NULL,
  summary_json TEXT
);

CREATE TABLE IF NOT EXISTS match_players(
  match_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  seat INTEGER NOT NULL,
  team TEXT NOT NULL,
  result TEXT NOT NULL,
  PRIMARY KEY(match_id,user_id),
  FOREIGN KEY(match_id) REFERENCES matches(id) ON DELETE CASCADE,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS moderation_cases(
  id TEXT PRIMARY KEY,
  case_type TEXT NOT NULL,
  room_code TEXT,
  reporter_user_id INTEGER,
  target_user_id INTEGER,
  target_display_name TEXT,
  reason TEXT NOT NULL,
  details TEXT,
  penalty TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS user_penalties(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  penalty_type TEXT NOT NULL,
  reason TEXT NOT NULL,
  starts_at INTEGER NOT NULL,
  ends_at INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_matches_ended_at ON matches(ended_at DESC);
CREATE INDEX IF NOT EXISTS idx_penalties_user ON user_penalties(user_id, active, ends_at);

CREATE TABLE IF NOT EXISTS friend_requests(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_user_id INTEGER NOT NULL,
  to_user_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE(from_user_id,to_user_id),
  FOREIGN KEY(from_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(to_user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS friendships(
  user_id INTEGER NOT NULL,
  friend_user_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(user_id,friend_user_id),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(friend_user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS game_invites(
  id TEXT PRIMARY KEY,
  from_user_id INTEGER NOT NULL,
  to_user_id INTEGER NOT NULL,
  room_code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  FOREIGN KEY(from_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(to_user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_friend_requests_to ON friend_requests(to_user_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_friendships_user ON friendships(user_id);
CREATE INDEX IF NOT EXISTS idx_invites_to ON game_invites(to_user_id,status,created_at DESC);
`);

export function now(){ return Date.now(); }

export function userById(id){
  return db.prepare(`SELECT id,username,display_name,rank_name,level,xp,wins,losses,created_at,last_seen_at FROM users WHERE id=?`).get(id);
}

export function userByUsername(username){
  return db.prepare(`SELECT * FROM users WHERE username=? COLLATE NOCASE`).get(username);
}

export function createUser({username,passwordHash,displayName}){
  const ts=now();
  const info=db.prepare(`
    INSERT INTO users(username,password_hash,display_name,created_at,last_seen_at)
    VALUES(?,?,?,?,?)
  `).run(username,passwordHash,displayName,ts,ts);
  return userById(info.lastInsertRowid);
}

export function touchUser(id){
  db.prepare(`UPDATE users SET last_seen_at=? WHERE id=?`).run(now(),id);
}

export function setRankFromXp(userId){
  const row=db.prepare(`SELECT xp FROM users WHERE id=?`).get(userId);
  if(!row)return;
  const xp=row.xp||0;
  let level=1, rank="ضيف";
  if(xp>=9000){level=8;rank="أسطورة";}
  else if(xp>=6500){level=7;rank="سيد";}
  else if(xp>=4500){level=6;rank="كبير";}
  else if(xp>=2800){level=5;rank="شيخ";}
  else if(xp>=1600){level=4;rank="راعي المجلس";}
  else if(xp>=800){level=3;rank="ثقيل";}
  else if(xp>=300){level=2;rank="خوي";}
  db.prepare(`UPDATE users SET level=?,rank_name=? WHERE id=?`).run(level,rank,userId);
}

export function addMatchResult({roomCode,us,them,players,summary}){
  const ts=now();
  const winner=us>them?"us":"them";
  const trx=db.transaction(()=>{
    const info=db.prepare(`
      INSERT INTO matches(room_code,started_at,ended_at,team_us_score,team_them_score,winner_team,summary_json)
      VALUES(?,?,?,?,?,?,?)
    `).run(roomCode,ts,ts,us,them,winner,JSON.stringify(summary||{}));
    const matchId=info.lastInsertRowid;

    const ins=db.prepare(`INSERT INTO match_players(match_id,user_id,seat,team,result) VALUES(?,?,?,?,?)`);
    for(const p of players){
      if(!p.userId)continue;
      const team=p.seat%2===0?"us":"them";
      const result=team===winner?"win":"loss";
      ins.run(matchId,p.userId,p.seat,team,result);
      if(result==="win"){
        db.prepare(`UPDATE users SET wins=wins+1,xp=xp+120 WHERE id=?`).run(p.userId);
      }else{
        db.prepare(`UPDATE users SET losses=losses+1,xp=xp+35 WHERE id=?`).run(p.userId);
      }
      setRankFromXp(p.userId);
    }
    return matchId;
  });
  return trx();
}

export function recentMatches(userId,limit=20){
  return db.prepare(`
    SELECT m.id,m.room_code,m.ended_at,m.team_us_score,m.team_them_score,m.winner_team,
           mp.seat,mp.team,mp.result
    FROM match_players mp
    JOIN matches m ON m.id=mp.match_id
    WHERE mp.user_id=?
    ORDER BY m.ended_at DESC
    LIMIT ?
  `).all(userId,limit);
}

export function saveModerationCase(c){
  db.prepare(`
    INSERT OR REPLACE INTO moderation_cases(
      id,case_type,room_code,reporter_user_id,target_user_id,target_display_name,
      reason,details,penalty,status,created_at
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
  `).run(
    c.id,c.type||"unknown",c.roomCode||null,c.reporterUserId||null,c.targetUserId||null,
    c.targetDisplayName||null,c.reason||"غير محدد",c.details||"",c.penalty||null,c.status||"pending",c.ts||now()
  );
}

export function addPenalty({userId,type,reason,endsAt}){
  db.prepare(`
    INSERT INTO user_penalties(user_id,penalty_type,reason,starts_at,ends_at,active)
    VALUES(?,?,?,?,?,1)
  `).run(userId,type,reason,now(),endsAt);
}

export function activePenalty(userId){
  const ts=now();
  db.prepare(`UPDATE user_penalties SET active=0 WHERE active=1 AND ends_at<=?`).run(ts);
  return db.prepare(`
    SELECT * FROM user_penalties
    WHERE user_id=? AND active=1 AND ends_at>?
    ORDER BY ends_at DESC LIMIT 1
  `).get(userId,ts);
}


export function publicUserByUsername(username){
  return db.prepare(`
    SELECT id,username,display_name,rank_name,level,xp,wins,losses
    FROM users WHERE username=? COLLATE NOCASE
  `).get(String(username||"").trim());
}

export function searchUsers(query, currentUserId, limit=12){
  const q=`%${String(query||"").trim()}%`;
  if(q==="%%")return [];
  return db.prepare(`
    SELECT id,username,display_name,rank_name,level,wins,losses
    FROM users
    WHERE id<>?
      AND (username LIKE ? COLLATE NOCASE OR display_name LIKE ? COLLATE NOCASE)
    ORDER BY wins DESC, xp DESC
    LIMIT ?
  `).all(currentUserId,q,q,limit);
}

export function sendFriendRequest(fromUserId,toUserId){
  if(fromUserId===toUserId) throw new Error("لا يمكنك إضافة نفسك");
  const existing=db.prepare(`SELECT 1 FROM friendships WHERE user_id=? AND friend_user_id=?`).get(fromUserId,toUserId);
  if(existing) throw new Error("هذا المستخدم ضمن أصدقائك");
  const reverse=db.prepare(`
    SELECT * FROM friend_requests
    WHERE from_user_id=? AND to_user_id=? AND status='pending'
  `).get(toUserId,fromUserId);
  if(reverse) return acceptFriendRequest(reverse.id,toUserId);

  const ts=now();
  db.prepare(`
    INSERT INTO friend_requests(from_user_id,to_user_id,status,created_at,updated_at)
    VALUES(?,?,'pending',?,?)
    ON CONFLICT(from_user_id,to_user_id)
    DO UPDATE SET status='pending',updated_at=excluded.updated_at
  `).run(fromUserId,toUserId,ts,ts);
}

export function pendingFriendRequests(userId){
  return db.prepare(`
    SELECT fr.id,fr.created_at,
           u.id AS user_id,u.username,u.display_name,u.rank_name,u.level,u.wins,u.losses
    FROM friend_requests fr
    JOIN users u ON u.id=fr.from_user_id
    WHERE fr.to_user_id=? AND fr.status='pending'
    ORDER BY fr.created_at DESC
  `).all(userId);
}

export function acceptFriendRequest(requestId,userId){
  const trx=db.transaction(()=>{
    const r=db.prepare(`
      SELECT * FROM friend_requests WHERE id=? AND to_user_id=? AND status='pending'
    `).get(requestId,userId);
    if(!r) throw new Error("طلب الصداقة غير موجود");
    const ts=now();
    db.prepare(`UPDATE friend_requests SET status='accepted',updated_at=? WHERE id=?`).run(ts,requestId);
    db.prepare(`INSERT OR IGNORE INTO friendships(user_id,friend_user_id,created_at) VALUES(?,?,?)`).run(r.from_user_id,r.to_user_id,ts);
    db.prepare(`INSERT OR IGNORE INTO friendships(user_id,friend_user_id,created_at) VALUES(?,?,?)`).run(r.to_user_id,r.from_user_id,ts);
  });
  trx();
}

export function declineFriendRequest(requestId,userId){
  db.prepare(`
    UPDATE friend_requests SET status='declined',updated_at=?
    WHERE id=? AND to_user_id=? AND status='pending'
  `).run(now(),requestId,userId);
}

export function listFriends(userId){
  return db.prepare(`
    SELECT u.id,u.username,u.display_name,u.rank_name,u.level,u.wins,u.losses,f.created_at
    FROM friendships f
    JOIN users u ON u.id=f.friend_user_id
    WHERE f.user_id=?
    ORDER BY u.display_name COLLATE NOCASE
  `).all(userId);
}

export function removeFriend(userId,friendUserId){
  const trx=db.transaction(()=>{
    db.prepare(`DELETE FROM friendships WHERE user_id=? AND friend_user_id=?`).run(userId,friendUserId);
    db.prepare(`DELETE FROM friendships WHERE user_id=? AND friend_user_id=?`).run(friendUserId,userId);
  });
  trx();
}

export function createGameInvite({id,fromUserId,toUserId,roomCode,expiresAt}){
  db.prepare(`
    INSERT INTO game_invites(id,from_user_id,to_user_id,room_code,status,created_at,expires_at)
    VALUES(?,?,?,?, 'pending', ?,?)
  `).run(id,fromUserId,toUserId,roomCode,now(),expiresAt);
}

export function pendingInvites(userId){
  const ts=now();
  db.prepare(`UPDATE game_invites SET status='expired' WHERE status='pending' AND expires_at<=?`).run(ts);
  return db.prepare(`
    SELECT gi.id,gi.room_code,gi.created_at,gi.expires_at,
           u.id AS from_user_id,u.display_name AS from_name,u.username AS from_username
    FROM game_invites gi
    JOIN users u ON u.id=gi.from_user_id
    WHERE gi.to_user_id=? AND gi.status='pending' AND gi.expires_at>?
    ORDER BY gi.created_at DESC
  `).all(userId,ts);
}

export function updateInviteStatus(inviteId,userId,status){
  db.prepare(`
    UPDATE game_invites SET status=?
    WHERE id=? AND to_user_id=? AND status='pending'
  `).run(status,inviteId,userId);
}

export function profileById(userId){
  const u=userById(userId);
  if(!u)return null;
  const total=(u.wins||0)+(u.losses||0);
  return {
    ...u,
    total_matches:total,
    win_rate:total?Math.round((u.wins/total)*100):0
  };
}
