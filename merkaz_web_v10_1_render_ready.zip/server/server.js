import express from "express";
import http from "http";
import { Server } from "socket.io";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { registerAccount, loginAccount, issueToken, verifyToken, authMiddleware } from "./auth.js";
import {
  recentMatches, addMatchResult, saveModerationCase, addPenalty, activePenalty, userById,
  searchUsers, sendFriendRequest, pendingFriendRequests, acceptFriendRequest, declineFriendRequest,
  listFriends, removeFriend, createGameInvite, pendingInvites, updateInviteStatus, profileById
} from "./db.js";

const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const app=express();
const server=http.createServer(app);
const APP_ORIGIN=process.env.APP_ORIGIN||"*";
const io=new Server(server,{
  cors:{
    origin:APP_ORIGIN==="*" ? "*" : APP_ORIGIN.split(",").map(x=>x.trim()),
    methods:["GET","POST"]
  },
  pingTimeout:20000,
  pingInterval:25000
});
const PORT=process.env.PORT||3000;
const NODE_ENV=process.env.NODE_ENV||"development";
const TRUST_PROXY=process.env.TRUST_PROXY==="1";
const CANONICAL_HOST=process.env.CANONICAL_HOST||"";
const FORCE_HTTPS=process.env.FORCE_HTTPS==="1";

if(TRUST_PROXY) app.set("trust proxy",1);

app.use((req,res,next)=>{
  const forwardedProto=String(req.headers["x-forwarded-proto"]||"");
  const host=String(req.headers.host||"").split(":")[0];
  if(FORCE_HTTPS && NODE_ENV==="production" && forwardedProto && forwardedProto!=="https"){
    return res.redirect(301,`https://${host}${req.originalUrl}`);
  }
  if(CANONICAL_HOST && host===`www.${CANONICAL_HOST}`){
    return res.redirect(301,`https://${CANONICAL_HOST}${req.originalUrl}`);
  }
  next();
});

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy:false,
  crossOriginEmbedderPolicy:false
}));

const apiLimiter=rateLimit({
  windowMs:60*1000,
  limit:120,
  standardHeaders:"draft-7",
  legacyHeaders:false
});
const authLimiter=rateLimit({
  windowMs:15*60*1000,
  limit:25,
  standardHeaders:"draft-7",
  legacyHeaders:false,
  message:{ok:false,error:"محاولات كثيرة. حاول لاحقًا."}
});

app.use("/api",apiLimiter);
app.use("/api/auth",authLimiter);
app.use(express.json({limit:"200kb"}));

app.post("/api/auth/register", async (req,res)=>{
  try{
    if(req.body?.acceptConduct!==true) return res.status(400).json({ok:false,error:"يجب الموافقة على ميثاق مركاز"});
    const user=await registerAccount(req.body||{});
    const token=issueToken(user);
    res.json({ok:true,user,token});
  }catch(e){res.status(400).json({ok:false,error:e.message||"تعذر التسجيل"});}
});

app.post("/api/auth/login", async (req,res)=>{
  try{
    const user=await loginAccount(req.body||{});
    const token=issueToken(user);
    res.json({ok:true,user,token});
  }catch(e){res.status(401).json({ok:false,error:e.message||"تعذر الدخول"});}
});

app.get("/api/me",authMiddleware,(req,res)=>{
  res.json({ok:true,user:req.auth.user});
});

app.get("/api/me/matches",authMiddleware,(req,res)=>{
  res.json({ok:true,matches:recentMatches(req.auth.user.id,30)});
});


app.get("/api/profile/:id",authMiddleware,(req,res)=>{
  const p=profileById(Number(req.params.id));
  if(!p)return res.status(404).json({ok:false,error:"المستخدم غير موجود"});
  res.json({ok:true,profile:p});
});

app.get("/api/users/search",authMiddleware,(req,res)=>{
  const q=String(req.query.q||"").trim();
  res.json({ok:true,users:searchUsers(q,req.auth.user.id,12)});
});

app.get("/api/friends",authMiddleware,(req,res)=>{
  res.json({ok:true,friends:listFriends(req.auth.user.id),requests:pendingFriendRequests(req.auth.user.id)});
});

app.post("/api/friends/request",authMiddleware,(req,res)=>{
  try{
    sendFriendRequest(req.auth.user.id,Number(req.body?.userId));
    res.json({ok:true});
  }catch(e){res.status(400).json({ok:false,error:e.message||"تعذر إرسال الطلب"});}
});

app.post("/api/friends/accept",authMiddleware,(req,res)=>{
  try{
    acceptFriendRequest(Number(req.body?.requestId),req.auth.user.id);
    res.json({ok:true});
  }catch(e){res.status(400).json({ok:false,error:e.message||"تعذر قبول الطلب"});}
});

app.post("/api/friends/decline",authMiddleware,(req,res)=>{
  declineFriendRequest(Number(req.body?.requestId),req.auth.user.id);
  res.json({ok:true});
});

app.post("/api/friends/remove",authMiddleware,(req,res)=>{
  removeFriend(req.auth.user.id,Number(req.body?.userId));
  res.json({ok:true});
});

app.get("/api/invites",authMiddleware,(req,res)=>{
  res.json({ok:true,invites:pendingInvites(req.auth.user.id)});
});

app.use(express.static(path.join(__dirname,"..","public"),{etag:false,maxAge:0,setHeaders:(res)=>res.setHeader("Cache-Control","no-store, max-age=0")}));
app.get("/health",(_,res)=>res.json({
  ok:true,
  version:"v12.1-bot-fill",
  env:NODE_ENV,
  uptime:Math.round(process.uptime())
}));


const rooms=new Map();
const reconnectSlots=new Map(); // userId -> {roomCode,seat,expiresAt}
const onlineUsers=new Map(); // userId -> Set(socketId)
const userStatus=new Map(); // userId -> {state,roomCode,updatedAt}
const RECONNECT_GRACE_MS=2*60*1000;

/*
  Safety layer:
  - server-side checks for player names, room names and chat.
  - avoids exposing the exact blocked-word dictionary to clients.
  - normalize common Arabic letter variants and repeated characters.
  - intentionally conservative; production should combine this with a maintained moderation service.
*/
const blockedPatterns = [
  // إساءة مباشرة
  /(?:يا\s*)?(?:غبي|احمق|حمار|كلب|حقير|تافه|فاشل|وصخ|قذر)/i,
  /(?:انقلع|اخرس|اسكت\s*يا|تف\s*عليك)/i,
  /(?:الله\s*يلعن|ملعون|لعنه)/i,

  // تنمر وإذلال
  /(?:ما\s*تسوى|مايسوى|منحط|عديم\s*القيمه|ما\s*تفهم|ماعندك\s*سالفة)/i,

  // تعصب قبلي / مناطقي بصيغة مهينة
  /(?:قبيلتك|قبيلتكم|اهل\s*منطقتك|اهل\s*منطقتكم).*(?:اسوا|احقر|ما\s*تسوى|مايسوى|جهله|متخلف)/i,
  /(?:نكره|نحتقر|اطردوا).*(?:قبيله|منطقه|اهل)/i,

  // تحريض أو تهديد
  /(?:بوريك|بتندم|اكسر|اضرب|اقتلك|اذبحك|تهديد)/i,

  // ألفاظ عامة صريحة
  /(?:سب|شتم|قذف)/i
];

const moderationConfig = {
  maxChatLength: 120,
  maxNameLength: 24,
  maxRoomNameLength: 40,
  violationWindowMs: 24 * 60 * 60 * 1000,
  penalties: {
    1: { type: "warning", seconds: 0, label: "تنبيه" },
    2: { type: "mute", seconds: 10 * 60, label: "كتم 10 دقائق" },
    3: { type: "mute", seconds: 60 * 60, label: "كتم ساعة" },
    4: { type: "suspend", seconds: 24 * 60 * 60, label: "تعليق 24 ساعة" }
  }
};

const moderationCases = [];

function normalizeArabicText(input="") {
  return String(input)
    .normalize("NFKC")
    .replace(/[إأآٱ]/g,"ا")
    .replace(/ى/g,"ي")
    .replace(/ة/g,"ه")
    .replace(/[\u064B-\u065F\u0670]/g,"")
    .replace(/[0٠]/g,"o")
    .replace(/[1١]/g,"i")
    .replace(/[3٣]/g,"ع")
    .replace(/[4٤]/g,"ش")
    .replace(/[5٥]/g,"خ")
    .replace(/[7٧]/g,"ح")
    .replace(/[8٨]/g,"ق")
    .replace(/[9٩]/g,"ص")
    .replace(/[_\-.*~]+/g," ")
    .replace(/(.)\1{3,}/g,"$1$1")
    .replace(/\s+/g," ")
    .trim();
}

function moderationCheck(input, {max=80}={}) {
  const raw=String(input??"").trim();
  if (!raw) return {ok:false,msg:"النص فارغ",reason:"empty"};
  if (raw.length>max) return {ok:false,msg:"النص أطول من المسموح",reason:"too_long"};
  const t=normalizeArabicText(raw);
  if (blockedPatterns.some(rx=>rx.test(t))) {
    return {ok:false,msg:"هذا النص يخالف ميثاق مركاز",reason:"abusive_language"};
  }
  return {ok:true,text:raw};
}

function requireConductAgreement(payload={}) {
  return payload.acceptConduct === true;
}

function nowMs(){ return Date.now(); }

function ensureSafetyProfile(player){
  if(!player.safety){
    player.safety={
      violations:[],
      mutedUntil:0,
      suspendedUntil:0,
      reportsReceived:0
    };
  }
  return player.safety;
}

function activeViolations(player){
  const s=ensureSafetyProfile(player);
  const cutoff=nowMs()-moderationConfig.violationWindowMs;
  s.violations=s.violations.filter(v=>v.ts>=cutoff);
  return s.violations.length;
}

function moderationStatus(player){
  const s=ensureSafetyProfile(player);
  return {
    mutedUntil:s.mutedUntil||0,
    suspendedUntil:s.suspendedUntil||0,
    violationCount:activeViolations(player),
    reportsReceived:s.reportsReceived||0
  };
}

function applyViolation(room, player, reason, evidence=""){
  const s=ensureSafetyProfile(player);
  s.violations.push({ts:nowMs(),reason,evidence:String(evidence).slice(0,180)});
  const count=activeViolations(player);
  const step=Math.min(count,4);
  const penalty=moderationConfig.penalties[step];

  if(penalty.type==="mute"){
    s.mutedUntil=Math.max(s.mutedUntil||0, nowMs()+penalty.seconds*1000);
  }else if(penalty.type==="suspend"){
    s.suspendedUntil=Math.max(s.suspendedUntil||0, nowMs()+penalty.seconds*1000);
  }

  const caseRow={
    id:`case_${nowMs()}_${Math.random().toString(36).slice(2,8)}`,
    type:"auto_violation",
    roomCode:room?.code||null,
    playerId:player.id,
    targetUserId:player.userId||null,
    targetDisplayName:player.name,
    reason,
    penalty:penalty.label,
    ts:nowMs(),
    status:"auto"
  };
  moderationCases.push(caseRow);
  saveModerationCase(caseRow);

  if(player.userId && (penalty.type==="mute" || penalty.type==="suspend")){
    const endsAt=penalty.type==="mute" ? s.mutedUntil : s.suspendedUntil;
    addPenalty({userId:player.userId,type:penalty.type,reason,endsAt});
  }

  return {count, penalty};
}

const ranks=["7","8","9","J","Q","K","10","A"];
const suits=["♠","♥","♦","♣"];

function deck(){return suits.flatMap(s=>ranks.map(r=>({id:`${r}${s}`,rank:r,suit:s})));}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function roomPublic(r){
  return {
    code:r.code,name:r.name,isPublic:!!r.isPublic,createdByUserId:r.createdByUserId||null,players:r.players.map(p=>({id:p.id,name:p.name,rank:p.rank,seat:p.seat,isBot:!!p.isBot,safety:moderationStatus(p)})),
    started:r.started,history:r.history.slice(-24),settings:r.settings,
    state:r.state?{
      round:r.state.round,contract:r.state.contract,trump:r.state.trump,double:r.state.double,
      buyerSeat:r.state.buyerSeat??null,upCard:r.state.upCard||null,
      currentPlayerSeat:r.state.currentPlayerSeat,trick:r.state.trick,played:r.state.played,
      handCounts:Object.fromEntries(Object.entries(r.state.hands||{}).map(([k,v])=>[k,(v||[]).length])),
      usTotal:r.state.usTotal,themTotal:r.state.themTotal,auction:r.state.auction,
      projects:r.state.projects,belote:r.state.belote,kaboot:r.state.kaboot,
      roundRaw:r.state.roundRaw,roundTricks:r.state.roundTricks
    }:null
  };
}

const botTurnTimers=new Map();
const BOT_DELAY_MS=650;
const BOT_NAMES=["فهد","راكان","سعود"];

function makeBot(roomCode,seat,index=0){
  return {
    id:`bot:${roomCode}:${seat}`,
    userId:null,
    name:BOT_NAMES[index%BOT_NAMES.length],
    rank:"كمبيوتر",
    seat,
    isBot:true,
    safety:{violations:[],mutedUntil:0,suspendedUntil:0,reportsReceived:0}
  };
}
function botBySeat(r,seat){return r.players.find(p=>Number(p.seat)===Number(seat)&&p.isBot);}
function botTrumpScore(hand,suit){
  const w={J:8,"9":7,A:5,"10":4,K:2,Q:2,"8":1,"7":1};
  return hand.filter(c=>c.suit===suit).reduce((n,c)=>n+(w[c.rank]||0),0);
}
function botSunScore(hand){
  const w={A:5,"10":4,K:2,Q:2,J:1,"9":0,"8":0,"7":0};
  return hand.reduce((n,c)=>n+(w[c.rank]||0),0);
}
function botAuctionDecision(s,seat){
  const hand=s.hands[seat]||[];
  const round=Number(s.auction?.round||1);
  const passAction=round===1?"بس":"ولا";
  const pending=s.auction?.pendingBid||null;
  const offerSuit=s.upCard?.suit||"♠";
  const scored=suits.map(suit=>({suit,score:botTrumpScore(hand,suit)})).sort((a,b)=>b.score-a.score);
  const best=scored.find(x=>round>1?x.suit!==offerSuit:true)||scored[0]||{suit:offerSuit,score:0};
  const offer=scored.find(x=>x.suit===offerSuit)||{suit:offerSuit,score:0};
  const sun=botSunScore(hand);
  // بعد شراء الحكم لا يحق رفعه بحكم آخر؛ يبقى الصن أو التمرير.
  if(pending?.action==="حكم"){
    if(sun>=18)return {action:"صن",trump:null};
    return {action:passAction,trump:null};
  }
  // الصن أعلى من الحكم في هذا الإصدار؛ ينتظر اللاعب اكتمال تسلسل المزايدة بالتمرير.
  if(pending?.action==="صن")return {action:passAction,trump:null};
  if(sun>=18)return {action:"صن",trump:null};
  if(round===1 && offer.score>=12)return {action:"حكم",trump:offerSuit};
  if(round>1 && best.score>=13)return {action:"حكم",trump:best.suit};
  return {action:passAction,trump:null};
}
function botDeclareExtras(r,seat){
  const s=r.state,hand=s?.hands?.[seat]||[];
  if(!s?.contract)return;
  for(const name of ["أربعمئة","مئة","خمسين","سرا"]){
    if(validateProject(hand,name,s.contract,s.trump) && !s.projects.some(p=>p.seat===seat&&p.name===name)){
      s.projects.push({seat,name,value:projectValue(name)});
      break;
    }
  }
  if(s.contract==="حكم"&&s.trump&&hasBelote(hand,s.trump)&&!s.belote.some(b=>b.seat===seat)){
    s.belote.push({seat,value:20});
  }
}
function botChooseCard(s,seat){
  const hand=s.hands[seat]||[];
  const legal=hand.filter(c=>validatePlay(s,seat,c.id).ok);
  if(!legal.length)return null;
  const sorted=[...legal].sort((a,b)=>{
    const av=cardValue(a,s.contract,s.trump),bv=cardValue(b,s.contract,s.trump);
    if(av!==bv)return av-bv;
    const as=(s.contract==="حكم"&&a.suit===s.trump)?trumpStrength(a.rank):sunStrength(a.rank);
    const bs=(s.contract==="حكم"&&b.suit===s.trump)?trumpStrength(b.rank):sunStrength(b.rank);
    return as-bs;
  });
  return sorted[0];
}
function finalizeAuctionDeal(r,buyerSeat){
  const s=r.state;if(!s)return;
  s.buyerSeat=buyerSeat;
  if(s.upCard){
    s.hands[buyerSeat].push(s.upCard);
  }
  const stock=Array.isArray(s.stock)?s.stock:[];
  for(let seat=0;seat<4;seat++){
    while((s.hands[seat]||[]).length<8 && stock.length){
      s.hands[seat].push(stock.pop());
    }
  }
  s.stock=[];
}
function finalizePendingAuction(r){
  const s=r.state;if(!s)return false;
  const bid=s.auction?.pendingBid;
  if(!bid)return false;
  s.contract=bid.action;
  s.trump=bid.action==="حكم"?bid.trump:null;
  s.buyerSeat=bid.seat;
  s.auction.finished=true;
  s.currentPlayerSeat=bid.seat;
  finalizeAuctionDeal(r,bid.seat);
  return true;
}
function markAuctionActed(s,seat){
  if(!Array.isArray(s.auction.acted))s.auction.acted=[];
  if(!s.auction.acted.includes(Number(seat)))s.auction.acted.push(Number(seat));
}
function finishAuctionTurnOrAdvance(r,seat){
  const s=r.state;if(!s)return;
  if((s.auction.acted||[]).length>=4){
    if(s.auction.pendingBid){ finalizePendingAuction(r); return; }
    const redealt=resetAuctionAfterPasses(r);
    if(!redealt)s.auction.turn=0;
    return;
  }
  s.auction.turn=nextSeat(seat);
}
function applyAuctionAction(r,seat,action,trump){
  const s=r.state;if(!s)return {ok:false,msg:"لا توجد صكة"};
  if(s.auction.finished)return {ok:false,msg:"انتهت المزايدة"};
  if(Number(s.auction.turn)!==Number(seat))return {ok:false,msg:"ليس دورك في المزايدة"};
  const round=Number(s.auction.round||1);
  const passAction=round===1?"بس":"ولا";
  const pending=s.auction.pendingBid||null;
  if(action==="بس"||action==="ولا"){
    s.auction.log.push({seat,action:passAction,round});
    markAuctionActed(s,seat);
    finishAuctionTurnOrAdvance(r,seat);
    return {ok:true};
  }
  if(action!=="صن"&&action!=="حكم")return {ok:false,msg:"قرار شراء غير صالح"};
  if(pending?.action==="صن")return {ok:false,msg:"الصن أعلى شراء؛ المتاح الآن التمرير"};
  if(action==="حكم"&&pending)return {ok:false,msg:"لا يجي حكم فوق حكم في نفس الدورة؛ المتاح صن أو تمرير"};
  if(action==="حكم"){
    if(round===1){
      trump=s.upCard?.suit||trump;
    }else{
      if(!suits.includes(trump))return {ok:false,msg:"اختر نوع الحكم"};
      if(s.upCard?.suit===trump)return {ok:false,msg:"في الجولة الثانية اختر حكمًا مختلفًا عن الورقة المكشوفة"};
    }
  }
  const bid={seat,action,trump:action==="حكم"?trump:null,round};
  // الصن يرفع الحكم، والحكم الأول يبقى شراءً مبدئيًا حتى تنتهي فرص بقية اللاعبين في الدورة.
  s.auction.pendingBid=bid;
  s.auction.log.push({seat,action,trump:bid.trump,round,pending:true});
  markAuctionActed(s,seat);
  finishAuctionTurnOrAdvance(r,seat);
  return {ok:true};
}
function resetAuctionAfterPasses(r){
  const s=r.state;if(!s)return;
  if(Number(s.auction.round||1)===1){
    s.auction.round=2;
    s.auction.passes=0;
    s.auction.turn=0;
    s.auction.pendingBid=null;
    s.auction.acted=[];
    s.auction.log.push({system:true,action:"الجولة الثانية"});
    return false;
  }
  // الجميع مرّ مرتين: إعادة توزيع جديدة بلا نقاط.
  const keepRound=s.round;
  const usTotal=s.usTotal,themTotal=s.themTotal;
  newRound(r);
  r.state.round=keepRound;
  r.state.usTotal=usTotal;r.state.themTotal=themTotal;
  return true;
}
function scheduleBotTurn(r){
  const old=botTurnTimers.get(r.code); if(old)clearTimeout(old);
  botTurnTimers.delete(r.code);
  if(!r.started||!r.state)return;
  const s=r.state;
  const seat=s.contract?s.currentPlayerSeat:s.auction.turn;
  const bot=botBySeat(r,seat);
  if(!bot)return;
  const timer=setTimeout(()=>{
    botTurnTimers.delete(r.code);
    if(!r.started||!r.state)return;
    const currentSeat=r.state.contract?r.state.currentPlayerSeat:r.state.auction.turn;
    if(Number(currentSeat)!==Number(seat)||!botBySeat(r,seat))return;
    if(!r.state.contract){
      const d=botAuctionDecision(r.state,seat);
      applyAuctionAction(r,seat,d.action,d.trump||null);
    }else{
      botDeclareExtras(r,seat);
      const card=botChooseCard(r.state,seat);
      if(card){
        r.state.hands[seat]=r.state.hands[seat].filter(c=>c.id!==card.id);
        r.state.played.push({seat,card});
        if(r.state.played.length<4)r.state.currentPlayerSeat=nextSeat(seat);
        else finishTrick(r);
      }
    }
    emitRoom(r);
  },BOT_DELAY_MS);
  botTurnTimers.set(r.code,timer);
}

function makeRoom(code,name,{isPublic=false,createdByUserId=null}={}){return {
  code,name:name||"مجلس مركاز",isPublic:!!isPublic,createdByUserId,players:[],started:false,state:null,history:[],
  settings:{targetScore:152}
};}
function newRound(r){
  const d=shuffle(deck());
  const hands={0:[],1:[],2:[],3:[]};
  // مرحلة المزايدة تبدأ بخمس أوراق لكل لاعب + ورقة مكشوفة في الوسط.
  for(let i=0;i<5;i++)for(let seat=0;seat<4;seat++)hands[seat].push(d.pop());
  const upCard=d.pop();
  r.state={
    round:(r.state?.round||0)+1,contract:null,trump:null,double:1,buyerSeat:null,
    currentPlayerSeat:0,trick:1,played:[],hands,upCard,stock:d,usTotal:r.state?.usTotal||0,themTotal:r.state?.themTotal||0,
    auction:{turn:0,passes:0,finished:false,round:1,log:[],pendingBid:null,acted:[]},projects:[],belote:[],kaboot:null,
    roundRaw:{us:0,them:0},roundTricks:{us:0,them:0}
  };
  r.started=true;
}
function nextSeat(s){return (s+1)%4;}
function teamOf(seat){return seat%2===0?"us":"them";}
function sunStrength(rank){return ({A:80,"10":70,K:60,Q:50,J:40,"9":30,"8":20,"7":10})[rank];}
function trumpStrength(rank){return ({J:80,"9":70,A:60,"10":50,K:40,Q:30,"8":20,"7":10})[rank];}
function cardValue(c,contract,trump){
  if(contract==="حكم"&&c.suit===trump)return ({J:20,"9":14,A:11,"10":10,K:4,Q:3,"8":0,"7":0})[c.rank];
  return ({A:11,"10":10,K:4,Q:3,J:2,"9":0,"8":0,"7":0})[c.rank];
}
function beats(a,b,lead,contract,trump){
  if(contract==="حكم"){
    const at=a.suit===trump, bt=b.suit===trump;
    if(at&&!bt)return true;
    if(!at&&bt)return false;
    if(at&&bt)return trumpStrength(a.rank)>trumpStrength(b.rank);
  }
  if(a.suit!==b.suit){
    if(a.suit===lead&&b.suit!==lead)return true;
    return false;
  }
  return sunStrength(a.rank)>sunStrength(b.rank);
}
function validatePlay(s,seat,cardId){
  if(!s.contract)return {ok:false,msg:"لم تعتمد الصكة بعد"};
  if(s.currentPlayerSeat!==seat)return {ok:false,msg:"ليس دورك"};
  const hand=s.hands[seat]||[];
  const card=hand.find(c=>c.id===cardId);
  if(!card)return {ok:false,msg:"الورقة غير موجودة"};
  if(!s.played.length)return {ok:true,card};

  const lead=s.played[0].card.suit;
  const follow=hand.filter(c=>c.suit===lead);
  if(follow.length && card.suit!==lead)return {ok:false,msg:"يجب اتباع اللون"};

  if(!follow.length && s.contract==="حكم" && s.trump){
    const trumps=hand.filter(c=>c.suit===s.trump);
    if(trumps.length && card.suit!==s.trump)return {ok:false,msg:"يجب القطع بالحكم"};
    if(trumps.length && card.suit===s.trump){
      const currentTrumps=s.played.filter(p=>p.card.suit===s.trump).map(p=>p.card);
      if(currentTrumps.length){
        const best=currentTrumps.reduce((x,y)=>trumpStrength(y.rank)>trumpStrength(x.rank)?y:x);
        const higher=trumps.filter(c=>trumpStrength(c.rank)>trumpStrength(best.rank));
        if(higher.length && trumpStrength(card.rank)<=trumpStrength(best.rank))
          return {ok:false,msg:"يجب التكبير بالحكم عند القدرة"};
      }
    }
  }
  return {ok:true,card};
}
function winnerOf(s){
  const lead=s.played[0].card.suit;
  let w=s.played[0];
  for(const p of s.played.slice(1))if(beats(p.card,w.card,lead,s.contract,s.trump))w=p;
  return w;
}
function sequenceLength(cards,suit){
  const order=["7","8","9","10","J","Q","K","A"];
  const owned=cards.filter(c=>c.suit===suit).map(c=>order.indexOf(c.rank)).sort((a,b)=>a-b);
  let best=1,cur=1;
  for(let i=1;i<owned.length;i++){if(owned[i]===owned[i-1]+1){cur++;best=Math.max(best,cur)}else cur=1;}
  return best;
}
function validateProject(hand,name,contract,trump){
  if(name==="أربعمئة"){
    const aces=hand.filter(c=>c.rank==="A").length;
    return aces===4;
  }
  if(name==="مئة"){
    const quads=["10","J","Q","K","A"].some(r=>hand.filter(c=>c.rank===r).length===4);
    const seq5=suits.some(s=>sequenceLength(hand,s)>=5);
    return quads||seq5;
  }
  if(name==="خمسين")return suits.some(s=>sequenceLength(hand,s)===4);
  if(name==="سرا")return suits.some(s=>sequenceLength(hand,s)===3);
  return false;
}
function projectValue(name){return ({"سرا":20,"خمسين":50,"مئة":100,"أربعمئة":400})[name]||0;}
function hasBelote(hand,trump){
  return hand.some(c=>c.suit===trump&&c.rank==="K")&&hand.some(c=>c.suit===trump&&c.rank==="Q");
}
function normalizedRound(s,team){
  const raw=s.roundRaw[team];
  let n=s.contract==="صن"?Math.round(raw/5):Math.round(raw/10);
  const projectPoints=s.projects.filter(p=>teamOf(p.seat)===team).reduce((a,p)=>a+p.value,0);
  n+=Math.round(projectPoints/10);
  if(s.belote.some(b=>teamOf(b.seat)===team))n+=2;
  return n*s.double;
}
function finishTrick(r){
  const s=r.state,w=winnerOf(s),team=teamOf(w.seat);
  let pts=s.played.reduce((a,p)=>a+cardValue(p.card,s.contract,s.trump),0);
  if(s.trick===8)pts+=10;
  s.roundRaw[team]+=pts;
  s.roundTricks[team]+=1;
  r.history.push({type:"trick",round:s.round,trick:s.trick,winnerSeat:w.seat,team,raw:pts});
  s.played=[];
  s.currentPlayerSeat=w.seat;

  if(s.trick===8){
    if(s.roundTricks.us===8)s.kaboot="us";
    if(s.roundTricks.them===8)s.kaboot="them";
    let us=normalizedRound(s,"us"), them=normalizedRound(s,"them");
    if(s.kaboot==="us")us+=25*s.double;
    if(s.kaboot==="them")them+=25*s.double;
    s.usTotal+=us; s.themTotal+=them;
    r.history.push({type:"round",round:s.round,contract:s.contract,trump:s.trump,double:s.double,us,them,usTotal:s.usTotal,themTotal:s.themTotal,kaboot:s.kaboot,projects:s.projects,belote:s.belote});
    if(s.usTotal>=r.settings.targetScore||s.themTotal>=r.settings.targetScore){
      r.started=false;
      try{
        addMatchResult({
          roomCode:r.code,
          us:s.usTotal,
          them:s.themTotal,
          players:r.players.map(p=>({userId:p.userId,seat:p.seat})),
          summary:{round:s.round,history:r.history.slice(-30)}
        });
        for(const p of r.players){
          if(p.userId){
            const fresh=userById(p.userId);
            if(fresh)p.rank=fresh.rank_name;
          }
        }
      }catch(e){console.error("save match failed",e);}
      return;
    }
    newRound(r);
  } else s.trick++;
}
function emitPrivate(r){
  for(const p of r.players)io.to(p.id).emit("game:private",{hand:r.state?.hands?.[p.seat]||[],seat:p.seat});
}
function emitRoom(r){emitPrivate(r);io.to(r.code).emit("room:update",roomPublic(r));scheduleBotTurn(r);}


function markOnline(userId,socketId){
  const set=onlineUsers.get(userId)||new Set();
  set.add(socketId); onlineUsers.set(userId,set);
  if(!userStatus.has(userId)) userStatus.set(userId,{state:"online",roomCode:null,updatedAt:Date.now()});
}
function markOffline(userId,socketId){
  const set=onlineUsers.get(userId); if(!set)return;
  set.delete(socketId);
  if(set.size===0){
    onlineUsers.delete(userId);
    userStatus.set(userId,{state:"offline",roomCode:null,updatedAt:Date.now()});
  }else onlineUsers.set(userId,set);
}
function setStatus(userId,state,roomCode=null){
  userStatus.set(userId,{state,roomCode,updatedAt:Date.now()});
}
function socialSnapshot(userId){
  const friends=listFriends(userId).map(f=>({
    ...f,
    presence:userStatus.get(f.id)||{state:"offline",roomCode:null}
  }));
  return {friends,requests:pendingFriendRequests(userId),invites:pendingInvites(userId)};
}
function emitSocial(userId){
  const sockets=onlineUsers.get(userId)||new Set();
  for(const sid of sockets) io.to(sid).emit("social:update",socialSnapshot(userId));
}
function emitSocialForFriends(userId){
  emitSocial(userId);
  for(const f of listFriends(userId))emitSocial(f.id);
}
function publicLobby(){
  return [...rooms.values()]
    .filter(r=>r.isPublic && !r.started && r.players.length<4)
    .map(r=>({
      code:r.code,name:r.name,players:r.players.length,maxPlayers:4,
      owner:r.players[0]?.name||"—"
    }))
    .sort((a,b)=>b.players-a.players)
    .slice(0,30);
}
function broadcastLobby(){ io.emit("lobby:update",publicLobby()); }

io.use((socket,next)=>{
  const token=socket.handshake.auth?.token;
  const auth=token?verifyToken(token):null;
  if(!auth)return next(new Error("AUTH_REQUIRED"));
  socket.data.user=auth.user;
  next();
});

io.on("connection",socket=>{
  markOnline(socket.data.user.id,socket.id);
  setStatus(socket.data.user.id,"online",null);
  socket.emit("social:update",socialSnapshot(socket.data.user.id));
  socket.emit("lobby:update",publicLobby());
  emitSocialForFriends(socket.data.user.id);

  socket.emit("moderation:policy",{
    title:"ميثاق مركاز",
    slogan:"لعبة — احفظ لسانك، واحترم تُحترم",
    rules:["لا للسب والشتم","لا للتنمر","لا للتعصب القبلي أو العنصرية","لا للتهديد أو الإهانة","اللعب بروح رياضية واحترام الجميع"]
  });
  socket.on("room:create",(payload={})=>{
    const {code,name,isPublic=false}=payload;
    const playerName=socket.data.user?.display_name||"لاعب";
    if(!requireConductAgreement(payload))return socket.emit("error:msg","يجب الموافقة على ميثاق الاحترام قبل الدخول");
    if(!code)return socket.emit("error:msg","أدخل رمز المجلس");
    if(rooms.has(code))return socket.emit("error:msg","الرمز مستخدم");
    const pn=moderationCheck(playerName||"لاعب",{max:24});
    const rn=moderationCheck(name||"مجلس مركاز",{max:40});
    if(!pn.ok)return socket.emit("error:msg",pn.msg);
    if(!rn.ok)return socket.emit("error:msg",rn.msg);
    const r=makeRoom(code,rn.text,{isPublic,createdByUserId:socket.data.user.id});
    r.players.push({id:socket.id,userId:socket.data.user.id,name:pn.text,rank:socket.data.user.rank_name||"ضيف",seat:0,safety:{violations:[],mutedUntil:0,suspendedUntil:0,reportsReceived:0}});
    rooms.set(code,r);socket.join(code);socket.data.roomCode=code;socket.data.seat=0;
    setStatus(socket.data.user.id,"in_room",code);
    emitRoom(r);broadcastLobby();emitSocialForFriends(socket.data.user.id);
  });

  socket.on("room:create_bot_test",(payload={})=>{
    const playerName=socket.data.user?.display_name||"لاعب";
    if(!requireConductAgreement(payload))return socket.emit("error:msg","يجب الموافقة على ميثاق الاحترام قبل الدخول");
    const pn=moderationCheck(playerName,{max:24});
    if(!pn.ok)return socket.emit("error:msg",pn.msg);
    let code;
    do{code=`BOT${Math.floor(1000+Math.random()*9000)}`;}while(rooms.has(code));
    const r=makeRoom(code,"تجربة ضد الكمبيوتر",{isPublic:false,createdByUserId:socket.data.user.id});
    r.botTest=true;
    r.players.push({id:socket.id,userId:socket.data.user.id,name:pn.text,rank:socket.data.user.rank_name||"ضيف",seat:0,isBot:false,safety:{violations:[],mutedUntil:0,suspendedUntil:0,reportsReceived:0}});
    for(let seat=1;seat<4;seat++)r.players.push(makeBot(code,seat,seat-1));
    rooms.set(code,r);socket.join(code);socket.data.roomCode=code;socket.data.seat=0;
    setStatus(socket.data.user.id,"in_match",code);
    newRound(r);
    emitRoom(r);broadcastLobby();emitSocialForFriends(socket.data.user.id);
    socket.emit("bot:test_ready",{message:"بدأ وضع الاختبار ضد 3 لاعبين كمبيوتر"});
  });

  socket.on("room:join",(payload={})=>{
    const {code}=payload;
    const playerName=socket.data.user?.display_name||"لاعب";
    if(!requireConductAgreement(payload))return socket.emit("error:msg","يجب الموافقة على ميثاق الاحترام قبل الدخول");
    const pn=moderationCheck(playerName||"لاعب",{max:24});
    if(!pn.ok)return socket.emit("error:msg",pn.msg);
    const r=rooms.get(code);if(!r)return socket.emit("error:msg","المجلس غير موجود");

    const existingByUser=r.players.find(p=>p.userId===socket.data.user.id);
    if(existingByUser){
      existingByUser.id=socket.id;
      existingByUser.name=playerName;
      socket.join(code);socket.data.roomCode=code;socket.data.seat=existingByUser.seat;
      reconnectSlots.delete(socket.data.user.id);
      setStatus(socket.data.user.id,r.started?"in_match":"in_room",code);
      emitRoom(r);broadcastLobby();emitSocialForFriends(socket.data.user.id);return;
    }

    const slot=reconnectSlots.get(socket.data.user.id);
    let seat=null;
    if(slot && slot.roomCode===code && slot.expiresAt>Date.now() && !r.players.some(p=>p.seat===slot.seat)){
      seat=slot.seat;
      reconnectSlots.delete(socket.data.user.id);
    }
    if(seat===null){
      if(r.players.length>=4)return socket.emit("error:msg","المجلس مكتمل");
      seat=[0,1,2,3].find(x=>!r.players.some(p=>p.seat===x));
    }
    r.players.push({id:socket.id,userId:socket.data.user.id,name:pn.text,rank:socket.data.user.rank_name||"ضيف",seat,safety:{violations:[],mutedUntil:0,suspendedUntil:0,reportsReceived:0}});
    socket.join(code);socket.data.roomCode=code;socket.data.seat=seat;
    setStatus(socket.data.user.id,r.started?"in_match":"in_room",code);
    emitRoom(r);broadcastLobby();emitSocialForFriends(socket.data.user.id);
  });

  socket.on("room:auto_rejoin",({code})=>{
    if(!code)return;
    const r=rooms.get(code);
    if(!r)return socket.emit("room:rejoin_result",{ok:false,reason:"not_found"});
    const existing=r.players.find(p=>p.userId===socket.data.user.id);
    if(existing){
      existing.id=socket.id;
      socket.join(code);socket.data.roomCode=code;socket.data.seat=existing.seat;
      reconnectSlots.delete(socket.data.user.id);
      setStatus(socket.data.user.id,r.started?"in_match":"in_room",code);
      emitRoom(r);
      return socket.emit("room:rejoin_result",{ok:true,code});
    }
    const slot=reconnectSlots.get(socket.data.user.id);
    if(slot && slot.roomCode===code && slot.expiresAt>Date.now() && !r.players.some(p=>p.seat===slot.seat)){
      r.players.push({
        id:socket.id,userId:socket.data.user.id,name:socket.data.user.display_name,
        rank:socket.data.user.rank_name||"ضيف",seat:slot.seat,
        safety:{violations:[],mutedUntil:0,suspendedUntil:0,reportsReceived:0}
      });
      reconnectSlots.delete(socket.data.user.id);
      socket.join(code);socket.data.roomCode=code;socket.data.seat=slot.seat;
      setStatus(socket.data.user.id,r.started?"in_match":"in_room",code);
      emitRoom(r);broadcastLobby();emitSocialForFriends(socket.data.user.id);
      return socket.emit("room:rejoin_result",{ok:true,code});
    }
    socket.emit("room:rejoin_result",{ok:false,reason:"expired"});
  });

  socket.on("social:refresh",()=>{
    socket.emit("social:update",socialSnapshot(socket.data.user.id));
  });

  socket.on("friend:invite_to_room",({friendUserId})=>{
    const r=rooms.get(socket.data.roomCode);
    if(!r)return socket.emit("error:msg","أنت لست داخل مجلس");
    const friend=listFriends(socket.data.user.id).find(f=>f.id===Number(friendUserId));
    if(!friend)return socket.emit("error:msg","هذا المستخدم ليس ضمن أصدقائك");
    const id=crypto.randomUUID();
    const expiresAt=Date.now()+10*60*1000;
    createGameInvite({id,fromUserId:socket.data.user.id,toUserId:friend.id,roomCode:r.code,expiresAt});
    const payload={id,roomCode:r.code,fromName:socket.data.user.display_name,expiresAt};
    const sockets=onlineUsers.get(friend.id)||new Set();
    for(const sid of sockets)io.to(sid).emit("invite:new",payload);
    emitSocial(friend.id);
    socket.emit("invite:sent",{message:"تم إرسال الدعوة"});
  });

  socket.on("invite:respond",({inviteId,accept})=>{
    const inv=pendingInvites(socket.data.user.id).find(x=>x.id===inviteId);
    if(!inv)return socket.emit("error:msg","الدعوة غير متاحة");
    updateInviteStatus(inviteId,socket.data.user.id,accept?"accepted":"declined");
    emitSocial(socket.data.user.id);
    if(accept)socket.emit("invite:accepted",{roomCode:inv.room_code});
  });

  socket.on("game:start_with_bots",()=>{
    const r=rooms.get(socket.data.roomCode);if(!r)return;
    if(r.started)return socket.emit("error:msg","المباراة بدأت بالفعل");
    const empty=[0,1,2,3].filter(seat=>!r.players.some(p=>Number(p.seat)===seat));
    for(const seat of empty){
      r.players.push(makeBot(r.code,seat,seat));
    }
    if(r.players.length!==4)return socket.emit("error:msg","تعذر تجهيز لاعبي الكمبيوتر");
    r.botTest=true;
    newRound(r);
    for(const p of r.players) if(p.userId) setStatus(p.userId,"in_match",r.code);
    emitRoom(r);broadcastLobby();
    for(const p of r.players) if(p.userId) emitSocialForFriends(p.userId);
    socket.emit("bot:test_ready",{message:"تم ملء المقاعد وبدأت المباراة ضد الكمبيوتر"});
  });

  socket.on("game:start",()=>{
    const r=rooms.get(socket.data.roomCode);if(!r)return;
    if(r.started)return socket.emit("error:msg","المباراة بدأت بالفعل");
    if(r.players.length!==4)return socket.emit("error:msg","يجب وجود 4 لاعبين");
    newRound(r);
    for(const p of r.players) if(p.userId) setStatus(p.userId,"in_match",r.code);
    emitRoom(r);broadcastLobby();
    for(const p of r.players) if(p.userId) emitSocialForFriends(p.userId);
  });
  socket.on("auction:action",({action,trump})=>{
    const r=rooms.get(socket.data.roomCode);if(!r?.state)return;
    const result=applyAuctionAction(r,socket.data.seat,action,trump);
    if(!result.ok)return socket.emit("error:msg",result.msg||"تعذر تنفيذ قرار المزايدة");
    emitRoom(r);
  });
  socket.on("game:double",()=>{
    const r=rooms.get(socket.data.roomCode);if(!r?.state?.contract)return;
    if(r.state.double<4)r.state.double*=2;
    emitRoom(r);
  });
  socket.on("game:project",({name})=>{
    const r=rooms.get(socket.data.roomCode);if(!r?.state)return;
    const seat=socket.data.seat,hand=r.state.hands[seat];
    if(!validateProject(hand,name,r.state.contract,r.state.trump))return socket.emit("error:msg","أوراقك لا تحقق هذا المشروع");
    if(r.state.projects.some(p=>p.seat===seat&&p.name===name))return;
    r.state.projects.push({seat,name,value:projectValue(name)});
    emitRoom(r);
  });
  socket.on("game:belote",()=>{
    const r=rooms.get(socket.data.roomCode);if(!r?.state)return;
    const s=r.state,seat=socket.data.seat;
    if(s.contract!=="حكم"||!s.trump)return socket.emit("error:msg","البلوت في الحكم فقط");
    if(!hasBelote(s.hands[seat],s.trump))return socket.emit("error:msg","لا تملك الشايب والبنت من الحكم");
    if(!s.belote.some(b=>b.seat===seat))s.belote.push({seat,value:20});
    emitRoom(r);
  });
  socket.on("game:play",({cardId})=>{
    const r=rooms.get(socket.data.roomCode);if(!r?.state)return;
    const seat=socket.data.seat,v=validatePlay(r.state,seat,cardId);
    if(!v.ok)return socket.emit("error:msg",v.msg);
    r.state.hands[seat]=r.state.hands[seat].filter(c=>c.id!==cardId);
    r.state.played.push({seat,card:v.card});
    if(r.state.played.length<4)r.state.currentPlayerSeat=nextSeat(seat);
    else finishTrick(r);
    emitRoom(r);
  });

  socket.on("chat:send",({text})=>{
    const r=rooms.get(socket.data.roomCode);if(!r)return;
    const p=r.players.find(x=>x.id===socket.id);
    if(!p)return;

    const safety=ensureSafetyProfile(p);
    if(p.userId){
      const persisted=activePenalty(p.userId);
      if(persisted && persisted.ends_at>nowMs()){
        if(persisted.penalty_type==="suspend"){
          safety.suspendedUntil=Math.max(safety.suspendedUntil||0,persisted.ends_at);
        }else if(persisted.penalty_type==="mute"){
          safety.mutedUntil=Math.max(safety.mutedUntil||0,persisted.ends_at);
        }
      }
    }
    if((safety.suspendedUntil||0)>nowMs()){
      return socket.emit("moderation:action",{
        type:"suspended",
        message:"تم تعليق حسابك مؤقتًا بسبب مخالفات متكررة لميثاق مركاز.",
        until:safety.suspendedUntil
      });
    }
    if((safety.mutedUntil||0)>nowMs()){
      return socket.emit("moderation:action",{
        type:"muted",
        message:"الدردشة مكتومة مؤقتًا بسبب مخالفة سابقة.",
        until:safety.mutedUntil
      });
    }

    const check=moderationCheck(text,{max:moderationConfig.maxChatLength});
    if(!check.ok){
      const action=applyViolation(r,p,check.reason,text);
      io.to(p.id).emit("moderation:action",{
        type:action.penalty.type,
        message:`تم حجب الرسالة. الإجراء: ${action.penalty.label}. تذكّر: احفظ لسانك، واحترم تُحترم.`,
        until:p.safety.mutedUntil||p.safety.suspendedUntil||0,
        violationCount:action.count
      });
      io.to(r.code).emit("room:update",roomPublic(r));
      return;
    }

    const msg={type:"chat",seat:p.seat,name:p.name,text:check.text,ts:Date.now()};
    r.history.push(msg);
    io.to(r.code).emit("chat:new",msg);
  });

  socket.on("player:report",({targetSeat,reason,details=""})=>{
    const r=rooms.get(socket.data.roomCode);if(!r)return;
    const reporter=r.players.find(x=>x.id===socket.id);
    const target=r.players.find(x=>x.seat===Number(targetSeat));
    if(!reporter||!target||reporter.id===target.id)return;

    const allowedReasons=["سب وشتم","تنمر","تعصب قبلي","عنصرية","تهديد","اسم غير لائق","إزعاج متكرر","أخرى"];
    if(!allowedReasons.includes(reason))return socket.emit("error:msg","سبب البلاغ غير صالح");
    const detailsCheck=details.trim()?moderationCheck(details,{max:180}):{ok:true,text:""};
    if(!detailsCheck.ok)return socket.emit("error:msg","وصف البلاغ يحتوي نصًا غير مناسب");

    ensureSafetyProfile(target).reportsReceived += 1;
    const reportCase={
      id:`report_${nowMs()}_${Math.random().toString(36).slice(2,8)}`,
      type:"player_report",
      roomCode:r.code,
      reporter:{id:reporter.id,name:reporter.name,seat:reporter.seat},
      target:{id:target.id,name:target.name,seat:target.seat},
      reporterUserId:reporter.userId||null,
      targetUserId:target.userId||null,
      targetDisplayName:target.name,
      reason,
      details:detailsCheck.text||"",
      ts:nowMs(),
      status:"pending"
    };
    moderationCases.push(reportCase);
    saveModerationCase(reportCase);

    socket.emit("report:received",{message:"تم استلام البلاغ. لن يتم معاقبة اللاعب تلقائيًا اعتمادًا على بلاغ واحد فقط."});
    io.to(r.code).emit("room:update",roomPublic(r));
  });

  socket.on("player:mute_local",({targetSeat})=>{
    // الكتم المحلي يتم في الواجهة فقط؛ الحدث موجود للتدقيق المستقبلي ولا يغير حالة اللاعب.
    socket.emit("mute:local_ack",{targetSeat:Number(targetSeat)});
  });

  socket.on("disconnect",()=>{
    const r=rooms.get(socket.data.roomCode);
    if(!r){
      markOffline(socket.data.user.id,socket.id);
      emitSocialForFriends(socket.data.user.id);
      return;
    }
    const p=r.players.find(x=>x.id===socket.id);
    if(p?.userId){
      reconnectSlots.set(p.userId,{roomCode:r.code,seat:p.seat,expiresAt:Date.now()+RECONNECT_GRACE_MS});
    }
    r.players=r.players.filter(x=>x.id!==socket.id);

    markOffline(socket.data.user.id,socket.id);
    if(onlineUsers.has(socket.data.user.id)){
      setStatus(socket.data.user.id,"online",null);
    }

    const humansLeft=r.players.filter(x=>!x.isBot);
    if(!humansLeft.length){
      broadcastLobby();emitSocialForFriends(socket.data.user.id);
      const t=botTurnTimers.get(r.code);if(t)clearTimeout(t);botTurnTimers.delete(r.code);
      setTimeout(()=>{
        const current=rooms.get(r.code);
        if(current && current.players.filter(x=>!x.isBot).length===0){rooms.delete(r.code);broadcastLobby();}
      },RECONNECT_GRACE_MS);
      return;
    }
    emitRoom(r);broadcastLobby();emitSocialForFriends(socket.data.user.id);
  });
});

const httpServer=server.listen(PORT,"0.0.0.0",()=>{
  console.log(`Merkaz V13 Game Table Beta on port ${PORT}`);
});

function shutdown(signal){
  console.log(`${signal}: shutting down`);
  httpServer.close(()=>process.exit(0));
  setTimeout(()=>process.exit(1),10000).unref();
}
process.on("SIGTERM",()=>shutdown("SIGTERM"));
process.on("SIGINT",()=>shutdown("SIGINT"));
