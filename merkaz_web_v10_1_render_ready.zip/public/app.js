let authToken=localStorage.getItem("merkaz_token")||"";
let accountUser=null;
let socket=null;
let room=null,myHand=[],mySeat=null;
const localMutedSeats=new Set();
let moderationPolicy=null;
let socialState={friends:[],requests:[],invites:[]};
let lobbyRooms=[];
let lastRoomCode=localStorage.getItem("merkaz_last_room")||"";

function connectSocket(){
  if(socket){socket.disconnect();}
  socket=io({auth:{token:authToken}});
  bindSocketEvents();
}
function bindSocketEvents(){
socket.on("connect",()=>{
  document.getElementById("connection").textContent="متصل";
  if(lastRoomCode)showRejoin(lastRoomCode);
  socket.emit("social:refresh");
});
socket.on("error:msg",toast);
socket.on("game:private",d=>{myHand=d.hand;mySeat=d.seat;renderHand()});
socket.on("room:update",d=>{
  room=d;
  if(d?.code){lastRoomCode=d.code;localStorage.setItem("merkaz_last_room",d.code);}
  showRoom();render();
});
socket.on("social:update",s=>{socialState=s||socialState;renderSocial()});
socket.on("lobby:update",rooms=>{lobbyRooms=rooms||[];renderLobby()});
socket.on("invite:new",inv=>{
  toast(`دعوة لعب من ${inv.fromName}`);
  socket.emit("social:refresh");
});
socket.on("invite:sent",d=>toast(d.message||"تم إرسال الدعوة"));
socket.on("invite:accepted",({roomCode})=>{
  if(roomCode){jcode.value=roomCode;joinRoom();}
});
socket.on("room:rejoin_result",r=>{
  if(!r.ok){
    if(r.reason==="expired"||r.reason==="not_found"){
      localStorage.removeItem("merkaz_last_room");lastRoomCode="";hideRejoin();
    }
    toast("تعذر استعادة المجلس");
  }
});
socket.on("moderation:policy",p=>{moderationPolicy=p});
socket.on("moderation:action",a=>{
  toast(a.message||"تم تطبيق إجراء أمان");
  if(a.type==="muted"||a.type==="suspended") showModerationBanner(a);
});
socket.on("report:received",d=>toast(d.message||"تم استلام البلاغ"));
socket.on("mute:local_ack",({targetSeat})=>{
  localMutedSeats.add(Number(targetSeat));
  render();
  toast("تم كتم رسائل هذا اللاعب لديك فقط");
});
socket.on("chat:new",m=>{
  if(localMutedSeats.has(Number(m.seat))) return;
  const box=document.getElementById("chatMessages"); if(!box)return;
  const row=document.createElement("div"); row.className="chatMsg";
  const name=document.createElement("b"); name.textContent=(m.name||"لاعب")+": ";
  const text=document.createElement("span"); text.textContent=m.text||"";
  row.append(name,text); box.appendChild(row); box.scrollTop=box.scrollHeight;
});

}
function showRoom(){document.getElementById("lobby").classList.remove("active");document.getElementById("room").classList.add("active")}
function acceptedConduct(){
  const ok=document.getElementById("conductAgree")?.checked===true;
  if(!ok)toast("وافق أولًا على ميثاق: احفظ لسانك، واحترم تُحترم");
  return ok;
}
function createRoom(){
  if(!acceptedConduct())return;
  socket.emit("room:create",{code:ccode.value.trim(),name:rname.value.trim(),isPublic:publicRoom.checked,acceptConduct:true})
}
function joinRoom(){
  if(!acceptedConduct())return;
  socket.emit("room:join",{code:jcode.value.trim(),acceptConduct:true})
}
function startGame(){socket.emit("game:start")}
function auction(action,trump=null){socket.emit("auction:action",{action,trump});closeModal()}
function chooseTrump(){modal(`<h3>اختر الحكم</h3>${["♠","♥","♦","♣"].map(s=>`<button onclick="auction('حكم','${s}')">${s}</button>`).join("")}`)}
function doubleGame(){socket.emit("game:double")}
function projects(){modal(`<h3>أعلن مشروعك</h3>${["سرا","خمسين","مئة","أربعمئة"].map(x=>`<button onclick="socket.emit('game:project',{name:'${x}'});closeModal()">${x}</button>`).join("")}`)}
function belote(){socket.emit("game:belote")}
function play(id){socket.emit("game:play",{cardId:id})}
function modal(h){modalBox.innerHTML=h+`<button onclick="closeModal()">إغلاق</button>`;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
function render(){
 if(!room)return; title.textContent=room.name;code.textContent=room.code;
 seats.innerHTML=[0,1,2,3].map(i=>{
  const p=room.players.find(x=>x.seat===i);
  if(!p)return `<div class="seat">＋<b>بانتظار لاعب</b><small>${i+1}</small></div>`;
  const mine=(i===mySeat);
  const safety=p.safety||{};
  const muted=localMutedSeats.has(i);
  return `<div class="seat">👤<b>${esc(p.name)}</b><small>${p.rank} • ${i+1}</small>
    <div class="seatSafety">${safety.violationCount?`تنبيهات: ${safety.violationCount}`:"سجل نظيف"}</div>
    ${mine?"":`<div class="seatActions">
      <button onclick="mutePlayer(${i})">${muted?"🔇 مكتوم":"🔈 كتم"}</button>
      <button onclick="reportPlayer(${i},'${esc(p.name)}')">🚩 إبلاغ</button>
    </div>`}
  </div>`
}).join("");
 game.classList.toggle("hidden",!room.state);if(!room.state)return;
 const s=room.state;us.textContent=s.usTotal;them.textContent=s.themTotal;contract.textContent=s.contract?`${s.contract}${s.trump?" "+s.trump:""}`:"بانتظار المزايدة";
 dbl.textContent=s.double===1?"عادي":`${s.double}x`;turn.textContent=`الدور: المقعد ${s.contract?s.currentPlayerSeat+1:s.auction.turn+1} • اللفة ${s.trick}`;
 played.innerHTML=(s.played||[]).map(p=>card(p.card,false)).join("");
 badges.innerHTML=[...(s.projects||[]).map(p=>`<div class="badge">${p.name} +${p.value}</div>`),...(s.belote||[]).map(()=>`<div class="badge">بلوت +20</div>`),...(s.kaboot?[`<div class="badge">كبوت</div>`]:[])].join("");
 auctionLog.innerHTML=(s.auction?.log||[]).slice().reverse().map(a=>`<div>المقعد ${a.seat+1}: ${a.action}${a.trump?" "+a.trump:""}</div>`).join("")||"<div>بانتظار المزايدة…</div>";
 history.innerHTML=(room.history||[]).slice().reverse().map(h=>h.type==="trick"?`<div>اللفة ${h.trick}: المقعد ${h.winnerSeat+1} • خام ${h.raw}</div>`:`<div>الصكة ${h.round}: ${h.contract}${h.trump?" "+h.trump:""} • ${h.double}x • لنا +${h.us} / لهم +${h.them}${h.kaboot?" • كبوت":""}</div>`).join("")||"<div>لا يوجد سجل بعد</div>";
 renderHand();
}
function renderHand(){const e=document.getElementById("hand");if(!e)return;e.innerHTML=myHand.map(c=>`<div class="card ${red(c.suit)?"red":""}" onclick="play('${c.id}')">${c.rank}${c.suit}</div>`).join("")}
function card(c){return `<div class="card ${red(c.suit)?"red":""}">${c.rank}${c.suit}</div>`}
function red(s){return s==="♥"||s==="♦"}
function toast(t){const e=document.getElementById("toast");e.textContent=t;e.classList.remove("hidden");setTimeout(()=>e.classList.add("hidden"),2200)}
function esc(s){return (s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function sendChat(){
  const i=document.getElementById("chatInput");
  const text=(i?.value||"").trim();
  if(!text)return;
  socket.emit("chat:send",{text});
  i.value="";
}
document.addEventListener("keydown",e=>{
  if(e.key==="Enter" && document.activeElement?.id==="chatInput") sendChat();
});

function mutePlayer(seat){
  seat=Number(seat);
  if(localMutedSeats.has(seat)){
    localMutedSeats.delete(seat);
    render();
    toast("تم إلغاء الكتم المحلي");
    return;
  }
  socket.emit("player:mute_local",{targetSeat:seat});
}

function reportPlayer(seat,name){
  const reasons=["سب وشتم","تنمر","تعصب قبلي","عنصرية","تهديد","اسم غير لائق","إزعاج متكرر","أخرى"];
  modal(`<h3>الإبلاغ عن ${esc(name)}</h3>
    <p>اختر سبب البلاغ. البلاغ لا يعني عقوبة تلقائية، ويُراجع ضمن نظام الأمان.</p>
    <div class="reportReasons">
      ${reasons.map(r=>`<button onclick="submitReport(${seat},'${r.replace(/'/g,"\\'")}')">${r}</button>`).join("")}
    </div>`);
}

function submitReport(seat,reason){
  socket.emit("player:report",{targetSeat:Number(seat),reason,details:""});
  closeModal();
}

function openSafetyCenter(){
  const p=moderationPolicy||{
    title:"ميثاق مركاز",
    slogan:"لعبة — احفظ لسانك، واحترم تُحترم",
    rules:["لا للسب والشتم","لا للتنمر","لا للتعصب القبلي أو العنصرية","لا للتهديد أو الإهانة","اللعب بروح رياضية"]
  };
  modal(`<h3>🛡️ ${p.title}</h3>
    <div class="safetyCard"><h4>${p.slogan}</h4>
      <ul>${(p.rules||[]).map(r=>`<li>${r}</li>`).join("")}</ul>
    </div>
    <div class="safetyCard">
      <h4>نظام الإجراءات</h4>
      <p>تنبيه → كتم 10 دقائق → كتم ساعة → تعليق مؤقت عند تكرار المخالفة.</p>
      <small>البلاغات لا تنتج عقوبة تلقائية بمفردها لتقليل إساءة استخدام البلاغ.</small>
    </div>`);
}

function showModerationBanner(action){
  const box=document.getElementById("chatMessages");
  if(!box)return;
  const d=document.createElement("div");
  d.className="moderationBanner";
  d.innerHTML=`<b>تنبيه مركاز</b><br>${esc(action.message||"تم تطبيق إجراء أمان")}`;
  box.prepend(d);
}


async function api(path,options={}){
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(authToken)headers.Authorization=`Bearer ${authToken}`;
  const r=await fetch(path,{...options,headers});
  const d=await r.json().catch(()=>({ok:false,error:"استجابة غير صالحة"}));
  if(!r.ok)throw new Error(d.error||"حدث خطأ");
  return d;
}

async function register(){
  try{
    const d=await api("/api/auth/register",{method:"POST",body:JSON.stringify({
      username:regUser.value.trim(),
      displayName:regName.value.trim(),
      password:regPass.value,
      acceptConduct:registerConductAgree.checked
    })});
    setAuth(d.token,d.user);
    toast("تم إنشاء الحساب");
  }catch(e){toast(e.message)}
}

async function login(){
  try{
    const d=await api("/api/auth/login",{method:"POST",body:JSON.stringify({
      username:loginUser.value.trim(),password:loginPass.value
    })});
    setAuth(d.token,d.user);
    toast("تم تسجيل الدخول");
  }catch(e){toast(e.message)}
}

function setAuth(token,user){
  authToken=token;accountUser=user;
  localStorage.setItem("merkaz_token",token);
  renderAccount();
  connectSocket();
}

function logout(){
  localStorage.removeItem("merkaz_token");
  authToken="";accountUser=null;
  if(socket)socket.disconnect();
  renderAccount();
}

function renderAccount(){
  const logged=!!accountUser;
  document.getElementById("authArea")?.classList.toggle("hidden",logged);
  document.getElementById("accountArea")?.classList.toggle("hidden",!logged);
  if(logged){
    accountName.textContent=accountUser.display_name;
    accountRank.textContent=`${accountUser.rank_name} • المستوى ${accountUser.level} • XP ${accountUser.xp}`;
    accountWins.textContent=accountUser.wins;
    accountLosses.textContent=accountUser.losses;
    if(document.getElementById("profileName")){
      profileName.textContent=accountUser.display_name;
      profileRank.textContent=`${accountUser.rank_name} • المستوى ${accountUser.level}`;
      const total=(accountUser.wins||0)+(accountUser.losses||0);
      const rate=total?Math.round((accountUser.wins/total)*100):0;
      profileMeta.textContent=`${accountUser.wins} فوز • ${accountUser.losses} خسارة • نسبة الفوز ${rate}% • XP ${accountUser.xp}`;
    }
  }
}

async function refreshMe(){
  if(!authToken){renderAccount();return;}
  try{
    const d=await api("/api/me");
    accountUser=d.user;renderAccount();connectSocket();
  }catch{
    localStorage.removeItem("merkaz_token");authToken="";accountUser=null;renderAccount();
  }
}

async function loadMyMatches(){
  try{
    const d=await api("/api/me/matches");
    matchesPanel.classList.remove("hidden");
    myMatches.innerHTML=d.matches.length?d.matches.map(m=>{
      const mine=m.team==="us"?m.team_us_score:m.team_them_score;
      const other=m.team==="us"?m.team_them_score:m.team_us_score;
      return `<div class="matchRow"><div><b>${esc(m.room_code)}</b><small> • ${new Date(m.ended_at).toLocaleDateString("ar-SA")}</small></div><div class="${m.result}">${m.result==="win"?"فوز":"خسارة"} ${mine} - ${other}</div></div>`;
    }).join(""):"<p>لا توجد مباريات محفوظة بعد.</p>";
  }catch(e){toast(e.message)}
}

refreshMe();

function showHomeTab(id){
  document.querySelectorAll(".homeTab").forEach(x=>x.classList.add("hidden"));
  document.getElementById(id)?.classList.remove("hidden");
  document.querySelectorAll(".homeTabs button").forEach(b=>b.classList.remove("active"));
  const map={playTab:0,lobbyTab:1,socialTab:2,profileTab:3};
  const btn=document.querySelectorAll(".homeTabs button")[map[id]];
  if(btn)btn.classList.add("active");
  if(id==="socialTab")socket?.emit("social:refresh");
  if(id==="profileTab")loadMyMatches();
}

async function searchUsers(){
  const q=userSearch.value.trim();
  if(!q){searchResults.innerHTML="<p>اكتب اسمًا للبحث.</p>";return}
  try{
    const d=await api(`/api/users/search?q=${encodeURIComponent(q)}`);
    searchResults.innerHTML=d.users.length?d.users.map(u=>`
      <div class="personRow">
        <div class="grow"><b>${esc(u.display_name)}</b><small>@${esc(u.username)} • ${esc(u.rank_name)} • ${u.wins} فوز</small></div>
        <button onclick="sendFriendRequestTo(${u.id})">إضافة</button>
      </div>`).join(""):"<p>لا توجد نتائج.</p>";
  }catch(e){toast(e.message)}
}

async function sendFriendRequestTo(userId){
  try{
    await api("/api/friends/request",{method:"POST",body:JSON.stringify({userId})});
    toast("تم إرسال طلب الصداقة");
    socket?.emit("social:refresh");
  }catch(e){toast(e.message)}
}

async function acceptFriend(requestId){
  try{
    await api("/api/friends/accept",{method:"POST",body:JSON.stringify({requestId})});
    toast("تمت إضافة الصديق");
    socket?.emit("social:refresh");
  }catch(e){toast(e.message)}
}
async function declineFriend(requestId){
  await api("/api/friends/decline",{method:"POST",body:JSON.stringify({requestId})}).catch(e=>toast(e.message));
  socket?.emit("social:refresh");
}
async function removeFriendById(userId){
  if(!confirm("إزالة هذا الصديق؟"))return;
  await api("/api/friends/remove",{method:"POST",body:JSON.stringify({userId})}).catch(e=>toast(e.message));
  socket?.emit("social:refresh");
}

function presenceLabel(p){
  const state=p?.state||"offline";
  if(state==="in_match")return ["داخل مباراة","in_match"];
  if(state==="in_room")return ["داخل مجلس","in_room"];
  if(state==="online")return ["متصل","online"];
  return ["غير متصل","offline"];
}

function renderSocial(){
  if(!document.getElementById("friendsList"))return;
  const friends=socialState.friends||[];
  friendsList.innerHTML=friends.length?friends.map(f=>{
    const [label,cls]=presenceLabel(f.presence);
    const canInvite=room?.code && f.presence?.state!=="in_match";
    return `<div class="personRow">
      <div class="grow"><b>${esc(f.display_name)}</b><small>@${esc(f.username)} • ${esc(f.rank_name)} • <span class="presence ${cls}">${label}</span></small></div>
      ${canInvite?`<button onclick="inviteFriend(${f.id})">دعوة</button>`:""}
      <button class="ghost" onclick="removeFriendById(${f.id})">إزالة</button>
    </div>`;
  }).join(""):"<p>لم تضف أصدقاء بعد.</p>";

  const req=socialState.requests||[];
  friendRequests.innerHTML=req.length?req.map(r=>`
    <div class="personRow">
      <div class="grow"><b>${esc(r.display_name)}</b><small>@${esc(r.username)} • ${esc(r.rank_name)}</small></div>
      <button onclick="acceptFriend(${r.id})">قبول</button>
      <button class="ghost" onclick="declineFriend(${r.id})">رفض</button>
    </div>`).join(""):"<p>لا توجد طلبات جديدة.</p>";

  const inv=socialState.invites||[];
  invitesList.innerHTML=inv.length?inv.map(i=>`
    <div class="inviteRow">
      <div class="grow"><b>دعوة من ${esc(i.from_name)}</b><small>المجلس: ${esc(i.room_code)}</small></div>
      <button onclick="respondInvite('${i.id}',true)">دخول</button>
      <button class="ghost" onclick="respondInvite('${i.id}',false)">رفض</button>
    </div>`).join(""):"<p>لا توجد دعوات حالية.</p>";
}

function renderLobby(){
  if(!document.getElementById("publicLobbyList"))return;
  publicLobbyList.innerHTML=lobbyRooms.length?lobbyRooms.map(r=>`
    <div class="lobbyRow">
      <div class="grow"><b>${esc(r.name)}</b><small>${r.players}/4 لاعبين • المضيف ${esc(r.owner)} • الرمز ${esc(r.code)}</small></div>
      <button onclick="joinPublicRoom('${r.code}')">دخول</button>
    </div>`).join(""):"<p>لا توجد مجالس عامة متاحة الآن.</p>";
}
function joinPublicRoom(code){jcode.value=code;showHomeTab("playTab");joinRoom()}

function inviteFriend(userId){socket?.emit("friend:invite_to_room",{friendUserId:userId})}
function respondInvite(inviteId,accept){socket?.emit("invite:respond",{inviteId,accept})}

function openInviteFriends(){
  const friends=socialState.friends||[];
  const available=friends.filter(f=>f.presence?.state!=="in_match");
  modal(`<h3>دعوة صديق إلى المجلس</h3>${
    available.length?available.map(f=>`<button onclick="inviteFriend(${f.id});closeModal()">${esc(f.display_name)} — ${presenceLabel(f.presence)[0]}</button>`).join(""):"<p>لا يوجد أصدقاء متاحون الآن.</p>"
  }`);
}

function showRejoin(code){
  const card=document.getElementById("rejoinCard");if(!card)return;
  card.classList.remove("hidden");
  rejoinText.textContent=`الرمز ${code}`;
}
function hideRejoin(){document.getElementById("rejoinCard")?.classList.add("hidden")}
function tryAutoRejoin(){
  if(!lastRoomCode||!socket)return;
  socket.emit("room:auto_rejoin",{code:lastRoomCode});
}
function leaveRoomUI(){
  // نخرج من العرض فقط؛ المقعد يبقى محفوظًا لفترة السماح عند انقطاع الاتصال الحقيقي.
  room=null;myHand=[];mySeat=null;
  document.getElementById("room").classList.remove("active");
  document.getElementById("lobby").classList.add("active");
  if(lastRoomCode)showRejoin(lastRoomCode);
  socket?.emit("social:refresh");
}
