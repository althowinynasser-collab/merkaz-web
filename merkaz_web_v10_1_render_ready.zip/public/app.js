let authToken=localStorage.getItem("merkaz_token")||"";
let accountUser=null;
let socket=null;
let room=null,myHand=[],mySeat=null;
const localMutedSeats=new Set();
let moderationPolicy=null;
let socialState={friends:[],requests:[],invites:[]};
let lobbyRooms=[];
let lastRoomCode=localStorage.getItem("merkaz_last_room")||"";
let lastContractNoticeKey="";
let contractNoticeDismissed=true;
let contractNoticeTimer=null;

function connectSocket(){
  if(socket){socket.disconnect();}
  socket=io({auth:{token:authToken}});
  bindSocketEvents();
}
function bindSocketEvents(){
socket.on("connect",()=>{
  document.getElementById("connection").textContent="متصل";
  if(lastRoomCode)showRejoin(lastRoomCode);
  socket.emit("social:refresh");
});
socket.on("error:msg",toast);
socket.on("game:private",d=>{myHand=d.hand;mySeat=d.seat;renderHand();if(room)render()});
socket.on("room:update",d=>{
  room=d;
  if(d?.code){lastRoomCode=d.code;localStorage.setItem("merkaz_last_room",d.code);}
  showRoom();render();
});
socket.on("social:update",s=>{socialState=s||socialState;renderSocial()});
socket.on("lobby:update",rooms=>{lobbyRooms=rooms||[];renderLobby()});
socket.on("invite:new",inv=>{
  toast(`دعوة لعب من ${inv.fromName}`);
  socket.emit("social:refresh");
});
socket.on("invite:sent",d=>toast(d.message||"تم إرسال الدعوة"));
socket.on("invite:accepted",({roomCode})=>{
  if(roomCode){jcode.value=roomCode;joinRoom();}
});
socket.on("room:rejoin_result",r=>{
  if(!r.ok){
    if(r.reason==="expired"||r.reason==="not_found"){
      localStorage.removeItem("merkaz_last_room");lastRoomCode="";hideRejoin();
    }
    toast("تعذر استعادة المجلس");
  }
});
socket.on("moderation:policy",p=>{moderationPolicy=p});
socket.on("moderation:action",a=>{
  toast(a.message||"تم تطبيق إجراء أمان");
  if(a.type==="muted"||a.type==="suspended") showModerationBanner(a);
});
socket.on("report:received",d=>toast(d.message||"تم استلام البلاغ"));
socket.on("bot:test_ready",d=>toast(d.message||"بدأ وضع الاختبار"));
socket.on("mute:local_ack",({targetSeat})=>{
  localMutedSeats.add(Number(targetSeat));
  render();
  toast("تم كتم رسائل هذا اللاعب لديك فقط");
});
socket.on("chat:new",m=>{
  if(localMutedSeats.has(Number(m.seat))) return;
  const box=document.getElementById("chatMessages"); if(!box)return;
  const row=document.createElement("div"); row.className="chatMsg";
  const name=document.createElement("b"); name.textContent=(m.name||"لاعب")+": ";
  const text=document.createElement("span"); text.textContent=m.text||"";
  row.append(name,text); box.appendChild(row); box.scrollTop=box.scrollHeight;
});

}
function showRoom(){document.getElementById("lobby").classList.remove("active");document.getElementById("room").classList.add("active")}
function acceptedConduct(){
  const ok=document.getElementById("conductAgree")?.checked===true;
  if(!ok)toast("وافق أولًا على ميثاق: احفظ لسانك، واحترم تُحترم");
  return ok;
}
function createRoom(){
  if(!acceptedConduct())return;
  socket.emit("room:create",{code:ccode.value.trim(),name:rname.value.trim(),isPublic:publicRoom.checked,acceptConduct:true})
}
function joinRoom(){
  if(!acceptedConduct())return;
  socket.emit("room:join",{code:jcode.value.trim(),acceptConduct:true})
}
function startBotTest(){
  if(!acceptedConduct())return;
  socket.emit("room:create_bot_test",{acceptConduct:true});
}
function startGame(){
  if(!room)return;
  if(room.started)return;
  if((room.players||[]).length<4){
    socket.emit("game:start_with_bots");
    return;
  }
  socket.emit("game:start");
}
function auction(action,trump=null){socket.emit("auction:action",{action,trump});closeModal()}
function chooseTrump(){
  const st=room?.state;
  if(!st)return;
  const round=Number(st.auction?.round||1);
  const offer=st.upCard?.suit||null;
  if(round===1 && offer){ auction('حكم',offer); return; }
  const choices=["♠","♥","♦","♣"].filter(x=>x!==offer);
  modal(`<h3>اختر الحكم</h3><p>الجولة الثانية — اختر لونًا مختلفًا عن الورقة المكشوفة.</p>${choices.map(x=>`<button onclick="auction('حكم','${x}')">${x}</button>`).join("")}`)
}
function doubleGame(){socket.emit("game:double")}
function projects(){modal(`<h3>أعلن مشروعك</h3>${["سرا","خمسين","مئة","أربعمئة"].map(x=>`<button onclick="socket.emit('game:project',{name:'${x}'});closeModal()">${x}</button>`).join("")}`)}
function belote(){socket.emit("game:belote")}
function play(id){socket.emit("game:play",{cardId:id})}
function modal(h){modalBox.innerHTML=h+`<button onclick="closeModal()">إغلاق</button>`;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
function seatPosition(seat){
  const base=(mySeat===null||mySeat===undefined)?0:Number(mySeat);
  return ["bottom","right","top","left"][(Number(seat)-base+4)%4];
}
function playerSeatMarkup(i,p,{compact=false,state=null}={}){
  if(!p){
    return compact?"":`<div class="seat waiting"><div class="seatAvatar">＋</div><b>بانتظار لاعب</b><small>المقعد ${i+1}</small></div>`;
  }
  const mine=(i===mySeat);
  const safety=p.safety||{};
  const muted=localMutedSeats.has(i);
  const current=state?(state.contract?state.currentPlayerSeat:state.auction?.turn):null;
  const turnClass=Number(current)===Number(i)?" isTurn":"";
  const initial=p.isBot?"🤖":esc((p.name||"؟").trim().slice(0,1).toUpperCase()||"؟");
  const rankLabel=p.isBot?"كمبيوتر":(p.rank||"ضيف");
  if(compact){
    const click=mine?"":`onclick="openPlayerMenu(${i})"`;
    const call=state&&!state.contract?lastSeatAction(state,i):null;
    const count=Number(state?.handCounts?.[i]??0);
    return `<div class="tableSeat ${seatPosition(i)}${mine?" mine":""}${turnClass}" ${click}>
      <div class="seatAvatar">${initial}</div>
      <div class="tableSeatText"><b>${esc(p.name)}${p.isBot?" 🤖":""}</b><small>${esc(rankLabel)}</small>${call?`<span class="seatCall">${esc(call)}</span>`:""}</div>
      ${!mine&&count?`<div class="seatCardFan" aria-label="${count} أوراق"><i></i><i></i><i></i></div>`:""}
      ${turnClass?'<span class="turnPulse"></span>':''}
    </div>`;
  }
  return `<div class="seat${mine?" mine":""}${turnClass}"><div class="seatAvatar">${initial}</div><b>${esc(p.name)}${p.isBot?" 🤖":""}</b><small>${esc(rankLabel)} • المقعد ${i+1}</small>
    <div class="seatSafety">${safety.violationCount?`تنبيهات: ${safety.violationCount}`:"سجل نظيف"}</div>
    ${mine||p.isBot?"":`<div class="seatActions">
      <button onclick="mutePlayer(${i})">${muted?"🔇 مكتوم":"🔈 كتم"}</button>
      <button onclick="reportPlayer(${i},'${esc(p.name)}')">🚩 إبلاغ</button>
    </div>`}
  </div>`;
}
function openPlayerMenu(seat){
  const p=room?.players?.find(x=>Number(x.seat)===Number(seat));
  if(!p||Number(seat)===Number(mySeat))return;
  if(p.isBot){modal(`<h3>${esc(p.name)} 🤖</h3><p>لاعب كمبيوتر للتجربة • المقعد ${Number(seat)+1}</p>`);return;}
  const muted=localMutedSeats.has(Number(seat));
  modal(`<h3>${esc(p.name)}</h3><p>${esc(p.rank||"ضيف")} • المقعد ${Number(seat)+1}</p>
    <button onclick="mutePlayer(${Number(seat)});closeModal()">${muted?"إلغاء الكتم":"🔈 كتم اللاعب"}</button>
    <button onclick="closeModal();reportPlayer(${Number(seat)},'${esc(p.name)}')">🚩 إبلاغ</button>`);
}
function seatName(seat){
  const p=room?.players?.find(x=>Number(x.seat)===Number(seat));
  return p?.name || `المقعد ${Number(seat)+1}`;
}
function contractLabel(contract,trump){
  if(!contract)return "بانتظار المزايدة";
  if(contract==="صن")return "صن ☀️";
  if(contract==="حكم")return `حكم ${trump||""}`.trim();
  return `${contract}${trump?` ${trump}`:""}`;
}
function actionLabel(action,trump){
  if(action==="بس")return "بس";
  if(action==="صن")return "صن ☀️";
  if(action==="حكم")return `حكم ${trump||""}`.trim();
  if(action==="الجولة الثانية")return "الجولة الثانية";
  return action || "";
}
function auctionEntries(state){ return (state?.auction?.log||[]).filter(x=>!x.system); }
function lastAuctionAction(state){
  const log=auctionEntries(state);
  return log.length?log[log.length-1]:null;
}
function lastSeatAction(state,seat){
  const row=[...auctionEntries(state)].reverse().find(x=>Number(x.seat)===Number(seat));
  return row?actionLabel(row.action,row.trump):null;
}
function turnMessage(state){
  if(!state)return "بانتظار بدء الصكة";
  if(!state.contract){
    const last=lastAuctionAction(state);
    const currentName=seatName(state.auction?.turn||0);
    const round=Number(state.auction?.round||1);
    if(last)return `${seatName(last.seat)} قال: ${actionLabel(last.action,last.trump)} • الدور على ${currentName}`;
    return `الجولة ${round===1?"الأولى":"الثانية"} • الدور على ${currentName}`;
  }
  const currentName=seatName(state.currentPlayerSeat||0);
  if((state.played||[]).length){
    const lastPlayed=state.played[state.played.length-1];
    return `${seatName(lastPlayed.seat)} لعب ${lastPlayed.card.rank}${lastPlayed.card.suit} • الدور على ${currentName}`;
  }
  return `${seatName(state.buyerSeat??state.currentPlayerSeat)} اشترى ${contractLabel(state.contract,state.trump)} • الدور على ${currentName}`;
}
function sortHand(cards,state){
  const suitOrderBase=["♠","♥","♦","♣"];
  const suitOrder = state?.contract==="حكم" && state?.trump
    ? [state.trump, ...suitOrderBase.filter(x=>x!==state.trump)]
    : suitOrderBase;
  const normal=["A","10","K","Q","J","9","8","7"];
  const trump=["J","9","A","10","K","Q","8","7"];
  return [...(cards||[])].sort((a,b)=>{
    const as=suitOrder.indexOf(a.suit), bs=suitOrder.indexOf(b.suit);
    if(as!==bs)return as-bs;
    const order=(state?.contract==="حكم"&&state?.trump===a.suit)?trump:normal;
    return order.indexOf(a.rank)-order.indexOf(b.rank);
  });
}
function handAdvice(cards,state){
  if(!cards?.length||state?.contract)return "";
  const offer=state?.upCard?.suit;
  const wTrump={J:8,"9":7,A:5,"10":4,K:2,Q:2,"8":1,"7":1};
  const wSun={A:5,"10":4,K:2,Q:2,J:1,"9":0,"8":0,"7":0};
  const trumpScore=(suit)=>cards.filter(c=>c.suit===suit).reduce((n,c)=>n+(wTrump[c.rank]||0),0);
  const sun=cards.reduce((n,c)=>n+(wSun[c.rank]||0),0);
  const best=["♠","♥","♦","♣"].map(suit=>({suit,score:trumpScore(suit)})).sort((a,b)=>b.score-a.score)[0];
  if(Number(state.auction?.round||1)===1 && offer && trumpScore(offer)>=10)return `قراءة اليد: الحكم ${offer} قابل للشراء`;
  if(sun>=15)return "قراءة اليد: الصن خيار قوي لهذه اليد";
  if(Number(state.auction?.round||1)>1 && best?.score>=11)return `قراءة اليد: أقوى حكم لديك ${best.suit}`;
  return "قراءة اليد: يد متوسطة — راقب الورقة المكشوفة قبل القرار";
}
function card(c,{compact=false,interactive=false}={}){
  if(!c)return "";
  const isRed=red(c.suit);
  const face=["K","Q","J"].includes(c.rank);
  const center=face?`<div class="centerMark face"><b>${c.rank}</b><small>${c.suit}</small></div>`:`<div class="centerMark">${c.suit}</div>`;
  return `<div class="playingCard${isRed?" red":""}${compact?" compact":""}${interactive?" interactive":""}" data-card-id="${c.id||""}">
    <div class="corner tl"><b>${c.rank}</b><span>${c.suit}</span></div>${center}<div class="corner br"><b>${c.rank}</b><span>${c.suit}</span></div>
  </div>`;
}
function renderPlayedCards(state){
  const e=document.getElementById("played");if(!e)return;
  const items=state?.played||[];
  if(!items.length){e.innerHTML="";return;}
  e.innerHTML=items.map(p=>`<div class="playedSlot ${seatPosition(p.seat)}"><div class="playedCardWrap"><div class="seatTag">${esc(seatName(p.seat))}</div>${card(p.card,{compact:true})}</div></div>`).join("");
}

function contractNoticeKey(state){
  return `${room?.code||""}-${state?.round||0}-${state?.trick||0}-${state?.contract||""}-${state?.trump||""}-${state?.buyerSeat??""}`;
}
function renderCenterBid(state){
  const box=document.getElementById("centerBid");if(!box)return;
  const hasContract=!!state?.contract;
  const hasPlayed=(state?.played||[]).length>0;
  if(!hasContract||hasPlayed){
    box.classList.add("hidden");
    box.innerHTML="";
    if(hasPlayed){ contractNoticeDismissed=true; }
    return;
  }
  const key=contractNoticeKey(state);
  if(key!==lastContractNoticeKey){
    lastContractNoticeKey=key;
    contractNoticeDismissed=false;
    if(contractNoticeTimer)clearTimeout(contractNoticeTimer);
    contractNoticeTimer=setTimeout(()=>{
      contractNoticeDismissed=true;
      const el=document.getElementById("centerBid");
      if(el) el.classList.add("hidden");
    },2200);
  }
  if(contractNoticeDismissed){
    box.classList.add("hidden");
    return;
  }
  const buyer=state.buyerSeat??state.currentPlayerSeat??0;
  box.innerHTML=`<b>${esc(seatName(buyer))} اشترى</b><small>${esc(contractLabel(state.contract,state.trump))}</small><span class="chip ${state.contract==="صن"?"sun":"trump"}">${esc(contractLabel(state.contract,state.trump))}</span>`;
  box.classList.remove("hidden");
}
function renderOffer(state){
  const zone=document.getElementById("offerZone");
  const slot=document.getElementById("upCard");
  const round=document.getElementById("offerRound");
  const hint=document.getElementById("handHint");
  if(!zone||!slot||!round||!hint)return;
  if(state?.contract){zone.classList.add("hidden");slot.innerHTML="";hint.textContent="";return;}
  zone.classList.remove("hidden");
  round.textContent=Number(state?.auction?.round||1)===1?"الجولة الأولى":"الجولة الثانية";
  slot.innerHTML=state?.upCard?card(state.upCard,{compact:false}):"";
  hint.innerHTML=`<strong>${esc(handAdvice(myHand,state))}</strong><span> — الورقة المكشوفة تظهر مرة واحدة لاتخاذ القرار.</span>`;
}
function renderMiniFeed(state){
  const feed=document.getElementById("miniFeed");if(!feed)return;
  const log=auctionEntries(state).slice(-4);
  const play=(state?.played||[]).slice(-2).map(p=>`${seatName(p.seat)} لعب ${p.card.rank}${p.card.suit}`);
  const items=state?.contract?play:log.map(a=>`${seatName(a.seat)}: ${actionLabel(a.action,a.trump)}`);
  feed.innerHTML=`<div class="miniFeedTitle">آخر الحركات</div><div class="miniFeedRow">${items.length?items.reverse().map(x=>`<span class="miniFeedItem">${esc(x)}</span>`).join(""):`<span class="miniFeedItem">بانتظار أول حركة</span>`}</div>`;
}
function renderStageActions(state){
  const auctionBox=document.getElementById("auctionActions");
  const playBox=document.getElementById("playActions");
  if(!auctionBox||!playBox)return;
  const isAuction=!state?.contract;
  auctionBox.classList.toggle("hidden",!isAuction);
  playBox.classList.toggle("hidden",isAuction);
  const myAuctionTurn=isAuction&&Number(state?.auction?.turn)===Number(mySeat);
  ["passBtn","sunBtn","trumpBtn"].forEach(id=>{const b=document.getElementById(id);if(b)b.disabled=!myAuctionTurn;});
  const trumpLabel=document.getElementById("trumpBtnLabel");
  const trumpSub=document.getElementById("trumpBtnSub");
  if(trumpLabel&&trumpSub&&isAuction){
    const round=Number(state?.auction?.round||1);
    const suit=state?.upCard?.suit||"";
    trumpLabel.textContent=round===1?`حكم ${suit}`:"اختر حكم";
    trumpSub.textContent=round===1?"على الورقة المكشوفة":"لون مختلف";
  }
}
function render(){
 if(!room)return;title.textContent=room.name;code.textContent=room.code;
 const startBtn=document.getElementById("startBtn");
 if(startBtn){
   startBtn.classList.toggle("hidden",!!room.started);
   if(!room.started){const missing=Math.max(0,4-(room.players||[]).length);startBtn.textContent=missing?`🤖 ابدأ مع ${missing} كمبيوتر`:`ابدأ المباراة`;}
 }
 seats.innerHTML=[0,1,2,3].map(i=>playerSeatMarkup(i,room.players.find(x=>x.seat===i))).join("");
 game.classList.toggle("hidden",!room.state);seats.classList.toggle("hidden",!!room.state);
 if(!room.state){const ts=document.getElementById("tableSeats");if(ts)ts.innerHTML="";return;}
 const s=room.state;
 const ts=document.getElementById("tableSeats");
 if(ts)ts.innerHTML=[0,1,2,3].map(i=>playerSeatMarkup(i,room.players.find(x=>x.seat===i),{compact:true,state:s})).join("");
 us.textContent=s.usTotal;them.textContent=s.themTotal;
 contract.textContent=s.contract?contractLabel(s.contract,s.trump):`المزايدة • ${Number(s.auction?.round||1)===1?"الجولة الأولى":"الجولة الثانية"}`;
 dbl.textContent=s.double===1?"عادي":`${s.double}x`;
 turn.textContent=`${seatName(s.contract?s.currentPlayerSeat:s.auction.turn)} • اللفة ${s.trick}`;
 const status=document.getElementById("statusLine");if(status)status.textContent=turnMessage(s);
 const handStage=document.getElementById("handStage");if(handStage)handStage.textContent=s.contract?"ورقك في اللعب":"ورقك للمزايدة";
 const handCount=document.getElementById("handCount");if(handCount)handCount.textContent=`${myHand.length} ${myHand.length===1?"ورقة":"أوراق"}`;
 renderOffer(s);renderPlayedCards(s);renderCenterBid(s);renderMiniFeed(s);renderStageActions(s);
 badges.innerHTML=[...(s.projects||[]).map(p=>`<div class="badge">${p.name} +${p.value}</div>`),...(s.belote||[]).map(()=>`<div class="badge">بلوت +20</div>`),...(s.kaboot?[`<div class="badge">كبوت</div>`]:[])].join("");
 auctionLog.innerHTML=auctionEntries(s).slice().reverse().map(a=>`<div>${esc(seatName(a.seat))}: ${esc(actionLabel(a.action,a.trump))}</div>`).join("")||"<div>بانتظار المزايدة…</div>";
 history.innerHTML=(room.history||[]).slice().reverse().map(h=>h.type==="trick"?`<div>اللفة ${h.trick}: ${esc(seatName(h.winnerSeat))} أخذ اللفة • خام ${h.raw}</div>`:`<div>الصكة ${h.round}: ${h.contract}${h.trump?" "+h.trump:""} • ${h.double}x • لنا +${h.us} / لهم +${h.them}${h.kaboot?" • كبوت":""}</div>`).join("")||"<div>لا يوجد سجل بعد</div>";
 renderHand();
}
function renderHand(){
  const e=document.getElementById("hand");if(!e)return;
  const state=room?.state;
  const sorted=sortHand(myHand,state);
  const myTurn=!!state?.contract&&Number(state.currentPlayerSeat)===Number(mySeat);
  e.innerHTML=sorted.map(c=>{
    let markup=card(c,{interactive:!!state?.contract});
    const extras=[state?.contract==="حكم"&&state?.trump===c.suit?"trumpCard":"",myTurn?"myTurn":"notPlayable"].filter(Boolean).join(" ");
    if(extras)markup=markup.replace('class="playingCard','class="playingCard '+extras);
    if(myTurn)markup=markup.replace('data-card-id="'+c.id+'"','data-card-id="'+c.id+'" onclick="play(\''+c.id+'\')"');
    return markup;
  }).join("");
}
function red(s){return s==="♥"||s==="♦"}
function toast(t){const e=document.getElementById("toast");e.textContent=t;e.classList.remove("hidden");setTimeout(()=>e.classList.add("hidden"),2200)}
function esc(s){return (s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function sendChat(){
  const i=document.getElementById("chatInput");
  const text=(i?.value||"").trim();
  if(!text)return;
  socket.emit("chat:send",{text});
  i.value="";
}
document.addEventListener("keydown",e=>{
  if(e.key==="Enter" && document.activeElement?.id==="chatInput") sendChat();
});

function mutePlayer(seat){
  seat=Number(seat);
  if(localMutedSeats.has(seat)){
    localMutedSeats.delete(seat);
    render();
    toast("تم إلغاء الكتم المحلي");
    return;
  }
  socket.emit("player:mute_local",{targetSeat:seat});
}

function reportPlayer(seat,name){
  const reasons=["سب وشتم","تنمر","تعصب قبلي","عنصرية","تهديد","اسم غير لائق","إزعاج متكرر","أخرى"];
  modal(`<h3>الإبلاغ عن ${esc(name)}</h3>
    <p>اختر سبب البلاغ. البلاغ لا يعني عقوبة تلقائية، ويُراجع ضمن نظام الأمان.</p>
    <div class="reportReasons">
      ${reasons.map(r=>`<button onclick="submitReport(${seat},'${r.replace(/'/g,"\\'")}')">${r}</button>`).join("")}
    </div>`);
}

function submitReport(seat,reason){
  socket.emit("player:report",{targetSeat:Number(seat),reason,details:""});
  closeModal();
}

function openSafetyCenter(){
  const p=moderationPolicy||{
    title:"ميثاق مركاز",
    slogan:"لعبة — احفظ لسانك، واحترم تُحترم",
    rules:["لا للسب والشتم","لا للتنمر","لا للتعصب القبلي أو العنصرية","لا للتهديد أو الإهانة","اللعب بروح رياضية"]
  };
  modal(`<h3>🛡️ ${p.title}</h3>
    <div class="safetyCard"><h4>${p.slogan}</h4>
      <ul>${(p.rules||[]).map(r=>`<li>${r}</li>`).join("")}</ul>
    </div>
    <div class="safetyCard">
      <h4>نظام الإجراءات</h4>
      <p>تنبيه → كتم 10 دقائق → كتم ساعة → تعليق مؤقت عند تكرار المخالفة.</p>
      <small>البلاغات لا تنتج عقوبة تلقائية بمفردها لتقليل إساءة استخدام البلاغ.</small>
    </div>`);
}

function showModerationBanner(action){
  const box=document.getElementById("chatMessages");
  if(!box)return;
  const d=document.createElement("div");
  d.className="moderationBanner";
  d.innerHTML=`<b>تنبيه مركاز</b><br>${esc(action.message||"تم تطبيق إجراء أمان")}`;
  box.prepend(d);
}


async function api(path,options={}){
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(authToken)headers.Authorization=`Bearer ${authToken}`;
  const r=await fetch(path,{...options,headers});
  const d=await r.json().catch(()=>({ok:false,error:"استجابة غير صالحة"}));
  if(!r.ok)throw new Error(d.error||"حدث خطأ");
  return d;
}

async function register(){
  try{
    const d=await api("/api/auth/register",{method:"POST",body:JSON.stringify({
      username:regUser.value.trim(),
      displayName:regName.value.trim(),
      password:regPass.value,
      acceptConduct:registerConductAgree.checked
    })});
    setAuth(d.token,d.user);
    toast("تم إنشاء الحساب");
  }catch(e){toast(e.message)}
}

async function login(){
  try{
    const d=await api("/api/auth/login",{method:"POST",body:JSON.stringify({
      username:loginUser.value.trim(),password:loginPass.value
    })});
    setAuth(d.token,d.user);
    toast("تم تسجيل الدخول");
  }catch(e){toast(e.message)}
}

function setAuth(token,user){
  authToken=token;accountUser=user;
  localStorage.setItem("merkaz_token",token);
  renderAccount();
  connectSocket();
}

function logout(){
  localStorage.removeItem("merkaz_token");
  authToken="";accountUser=null;
  if(socket)socket.disconnect();
  renderAccount();
}

function renderAccount(){
  const logged=!!accountUser;
  document.getElementById("authArea")?.classList.toggle("hidden",logged);
  document.getElementById("accountArea")?.classList.toggle("hidden",!logged);
  if(logged){
    accountName.textContent=accountUser.display_name;
    accountRank.textContent=`${accountUser.rank_name} • المستوى ${accountUser.level} • XP ${accountUser.xp}`;
    accountWins.textContent=accountUser.wins;
    accountLosses.textContent=accountUser.losses;
    if(document.getElementById("profileName")){
      profileName.textContent=accountUser.display_name;
      profileRank.textContent=`${accountUser.rank_name} • المستوى ${accountUser.level}`;
      const total=(accountUser.wins||0)+(accountUser.losses||0);
      const rate=total?Math.round((accountUser.wins/total)*100):0;
      profileMeta.textContent=`${accountUser.wins} فوز • ${accountUser.losses} خسارة • نسبة الفوز ${rate}% • XP ${accountUser.xp}`;
    }
  }
}

async function refreshMe(){
  if(!authToken){renderAccount();return;}
  try{
    const d=await api("/api/me");
    accountUser=d.user;renderAccount();connectSocket();
  }catch{
    localStorage.removeItem("merkaz_token");authToken="";accountUser=null;renderAccount();
  }
}

async function loadMyMatches(){
  try{
    const d=await api("/api/me/matches");
    matchesPanel.classList.remove("hidden");
    myMatches.innerHTML=d.matches.length?d.matches.map(m=>{
      const mine=m.team==="us"?m.team_us_score:m.team_them_score;
      const other=m.team==="us"?m.team_them_score:m.team_us_score;
      return `<div class="matchRow"><div><b>${esc(m.room_code)}</b><small> • ${new Date(m.ended_at).toLocaleDateString("ar-SA")}</small></div><div class="${m.result}">${m.result==="win"?"فوز":"خسارة"} ${mine} - ${other}</div></div>`;
    }).join(""):"<p>لا توجد مباريات محفوظة بعد.</p>";
  }catch(e){toast(e.message)}
}

refreshMe();

function showHomeTab(id){
  document.querySelectorAll(".homeTab").forEach(x=>x.classList.add("hidden"));
  document.getElementById(id)?.classList.remove("hidden");
  document.querySelectorAll(".homeTabs button").forEach(b=>b.classList.remove("active"));
  const map={playTab:0,lobbyTab:1,socialTab:2,profileTab:3};
  const btn=document.querySelectorAll(".homeTabs button")[map[id]];
  if(btn)btn.classList.add("active");
  if(id==="socialTab")socket?.emit("social:refresh");
  if(id==="profileTab")loadMyMatches();
}

async function searchUsers(){
  const q=userSearch.value.trim();
  if(!q){searchResults.innerHTML="<p>اكتب اسمًا للبحث.</p>";return}
  try{
    const d=await api(`/api/users/search?q=${encodeURIComponent(q)}`);
    searchResults.innerHTML=d.users.length?d.users.map(u=>`
      <div class="personRow">
        <div class="grow"><b>${esc(u.display_name)}</b><small>@${esc(u.username)} • ${esc(u.rank_name)} • ${u.wins} فوز</small></div>
        <button onclick="sendFriendRequestTo(${u.id})">إضافة</button>
      </div>`).join(""):"<p>لا توجد نتائج.</p>";
  }catch(e){toast(e.message)}
}

async function sendFriendRequestTo(userId){
  try{
    await api("/api/friends/request",{method:"POST",body:JSON.stringify({userId})});
    toast("تم إرسال طلب الصداقة");
    socket?.emit("social:refresh");
  }catch(e){toast(e.message)}
}

async function acceptFriend(requestId){
  try{
    await api("/api/friends/accept",{method:"POST",body:JSON.stringify({requestId})});
    toast("تمت إضافة الصديق");
    socket?.emit("social:refresh");
  }catch(e){toast(e.message)}
}
async function declineFriend(requestId){
  await api("/api/friends/decline",{method:"POST",body:JSON.stringify({requestId})}).catch(e=>toast(e.message));
  socket?.emit("social:refresh");
}
async function removeFriendById(userId){
  if(!confirm("إزالة هذا الصديق؟"))return;
  await api("/api/friends/remove",{method:"POST",body:JSON.stringify({userId})}).catch(e=>toast(e.message));
  socket?.emit("social:refresh");
}

function presenceLabel(p){
  const state=p?.state||"offline";
  if(state==="in_match")return ["داخل مباراة","in_match"];
  if(state==="in_room")return ["داخل مجلس","in_room"];
  if(state==="online")return ["متصل","online"];
  return ["غير متصل","offline"];
}

function renderSocial(){
  if(!document.getElementById("friendsList"))return;
  const friends=socialState.friends||[];
  friendsList.innerHTML=friends.length?friends.map(f=>{
    const [label,cls]=presenceLabel(f.presence);
    const canInvite=room?.code && f.presence?.state!=="in_match";
    return `<div class="personRow">
      <div class="grow"><b>${esc(f.display_name)}</b><small>@${esc(f.username)} • ${esc(f.rank_name)} • <span class="presence ${cls}">${label}</span></small></div>
      ${canInvite?`<button onclick="inviteFriend(${f.id})">دعوة</button>`:""}
      <button class="ghost" onclick="removeFriendById(${f.id})">إزالة</button>
    </div>`;
  }).join(""):"<p>لم تضف أصدقاء بعد.</p>";

  const req=socialState.requests||[];
  friendRequests.innerHTML=req.length?req.map(r=>`
    <div class="personRow">
      <div class="grow"><b>${esc(r.display_name)}</b><small>@${esc(r.username)} • ${esc(r.rank_name)}</small></div>
      <button onclick="acceptFriend(${r.id})">قبول</button>
      <button class="ghost" onclick="declineFriend(${r.id})">رفض</button>
    </div>`).join(""):"<p>لا توجد طلبات جديدة.</p>";

  const inv=socialState.invites||[];
  invitesList.innerHTML=inv.length?inv.map(i=>`
    <div class="inviteRow">
      <div class="grow"><b>دعوة من ${esc(i.from_name)}</b><small>المجلس: ${esc(i.room_code)}</small></div>
      <button onclick="respondInvite('${i.id}',true)">دخول</button>
      <button class="ghost" onclick="respondInvite('${i.id}',false)">رفض</button>
    </div>`).join(""):"<p>لا توجد دعوات حالية.</p>";
}

function renderLobby(){
  if(!document.getElementById("publicLobbyList"))return;
  publicLobbyList.innerHTML=lobbyRooms.length?lobbyRooms.map(r=>`
    <div class="lobbyRow">
      <div class="grow"><b>${esc(r.name)}</b><small>${r.players}/4 لاعبين • المضيف ${esc(r.owner)} • الرمز ${esc(r.code)}</small></div>
      <button onclick="joinPublicRoom('${r.code}')">دخول</button>
    </div>`).join(""):"<p>لا توجد مجالس عامة متاحة الآن.</p>";
}
function joinPublicRoom(code){jcode.value=code;showHomeTab("playTab");joinRoom()}

function inviteFriend(userId){socket?.emit("friend:invite_to_room",{friendUserId:userId})}
function respondInvite(inviteId,accept){socket?.emit("invite:respond",{inviteId,accept})}

function openInviteFriends(){
  const friends=socialState.friends||[];
  const available=friends.filter(f=>f.presence?.state!=="in_match");
  modal(`<h3>دعوة صديق إلى المجلس</h3>${
    available.length?available.map(f=>`<button onclick="inviteFriend(${f.id});closeModal()">${esc(f.display_name)} — ${presenceLabel(f.presence)[0]}</button>`).join(""):"<p>لا يوجد أصدقاء متاحون الآن.</p>"
  }`);
}

function showRejoin(code){
  const card=document.getElementById("rejoinCard");if(!card)return;
  card.classList.remove("hidden");
  rejoinText.textContent=`الرمز ${code}`;
}
function hideRejoin(){document.getElementById("rejoinCard")?.classList.add("hidden")}
function tryAutoRejoin(){
  if(!lastRoomCode||!socket)return;
  socket.emit("room:auto_rejoin",{code:lastRoomCode});
}
function leaveRoomUI(){
  // نخرج من العرض فقط؛ المقعد يبقى محفوظًا لفترة السماح عند انقطاع الاتصال الحقيقي.
  room=null;myHand=[];mySeat=null;
  document.getElementById("room").classList.remove("active");
  document.getElementById("lobby").classList.add("active");
  if(lastRoomCode)showRejoin(lastRoomCode);
  socket?.emit("social:refresh");
}
